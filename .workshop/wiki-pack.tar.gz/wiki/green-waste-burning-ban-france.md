---
type: Topic
title: "Ban on burning green waste in France"
description: "The French ban on burning garden/green waste, what counts as green waste, alternatives, exceptions, and penalties."
tags: [france, green-waste, prevention]
sources:
  - { id: dechets-verts-sp, resource: ../corpus/23-service-public-dechets-verts.html, title: "Peut-on brûler des déchets verts (végétaux) dans son jardin (feuilles, branches, ...) ?" }
  - { id: arrete-26eb142, resource: ../corpus/30-charente-maritime-arrete-26EB142.pdf, title: "Arrêté préfectoral n° 26EB142 réglementant l'usage du feu à l'air libre" }
generated: { by: claude-sonnet-5, at: 2026-10-20T10:30:00Z }
---
# Ban on burning green waste in France

It is forbidden to burn green waste at home, whether with a garden incinerator or in the open
air.[^dechets-verts-sp]

## What counts as green waste

Mainly the following vegetation: grass after lawn mowing, dead leaves, pruning residue from
hedges, shrubs and trees, and fruit and vegetable peelings.[^dechets-verts-sp]

## Allowed alternatives

- Using green waste as compost or mulch, since it is biodegradable (it decomposes over
  time).[^dechets-verts-sp]
- Depositing green waste following the rules set by the commune (déchetterie or collecte
  sélective).[^dechets-verts-sp]

## The ban

Burning green waste — dry or wet — is forbidden, whether in the open air or with a garden
incinerator.[^dechets-verts-sp] Burning green waste, especially when wet, releases substances
that are toxic to humans and the environment, notably fine particles.[^dechets-verts-sp]

## Exceptions

- **Dérogations** can exist in a commune if it has no déchetterie or no collecte sélective of
  green waste; to find out about the handling of green waste in a commune, or whether a
  dérogation applies there, the mairie should be contacted.[^dechets-verts-sp]
- The préfet can exceptionally grant an **individual dérogation** to eradicate épiphytie (a
  disease affecting certain plants) or to eliminate invasive plant species; people concerned
  by one of these situations should inquire with the préfecture.[^dechets-verts-sp]

## Enforcement and penalties

Anyone can alert the mairie's hygiene services ("services d'hygiène de la mairie") in case of
non-compliance with the ban; the mairie can then take the necessary measures to stop this
illegal practice.[^dechets-verts-sp] A person who burns green waste can be liable to a **fine of
750 €**; this fine also applies to a person who makes available or sells an incinerator for
eliminating green waste.[^dechets-verts-sp]

If someone is bothered by the odours or smoke from burned green waste, they can also pursue
their neighbour's liability for the resulting nuisance.[^dechets-verts-sp]

## A département going further: Charente-Maritime

In Charente-Maritime, the prefectoral order n° 26EB142 bans open-air burning, or burning with
individual incinerators, not just of green waste but of all types of waste (household,
green, forestry green, agricultural green, industrial and craft waste, plastics, rubber, treated
wood, oils, hydrocarbons), all year round and across the whole département, for individuals,
professionals and local authorities alike; individuals cannot obtain a dérogation for burning
green waste, unlike professionals who may request one in specific cases (contaminated green
waste, inaccessible forestry green waste, some agricultural residues).[^arrete-26eb142] This
source does not state a euro figure for the penalty: it describes violating the order's
prohibitions as punished by the fine for 1st-class contraventions, while non-compliance with the
departmental sanitary regulation (which also bars green-waste burning) is punished by the fine
for 3rd-class contraventions — different figures, in a different form, from the 750 € fine given
above.[^arrete-26eb142]

## Legal basis

- Code de l'environnement, article L541-21-1: prohibition of garden incinerators.[^dechets-verts-sp]
- Code de l'environnement, article R541-78: sanctions.[^dechets-verts-sp]
- Circulaire du 26 avril 1982 relative à la modification du règlement sanitaire départemental
  type, article 84.[^dechets-verts-sp]
- Réponse ministérielle du 12 septembre 2013 sur l'interdiction générale et permanente de
  brûlage des déchets végétaux.[^dechets-verts-sp]

## See also
- [Wildfire prevention and safety reflexes in France](wildfire-prevention-france.md)
- [Outdoor fire use regulation in Charente-Maritime (arrêté n° 26EB142)](outdoor-fire-regulation-charente-maritime.md)

[^dechets-verts-sp]: Peut-on brûler des déchets verts (végétaux) dans son jardin (feuilles, branches, ...) ?
[^arrete-26eb142]: Arrêté préfectoral n° 26EB142 réglementant l'usage du feu à l'air libre

---
type: Topic
title: "Bollettino di previsione nazionale incendi boschivi (Italy)"
description: "The Italian civil protection department's daily national forest-fire forecast bulletin: what it covers, its three danger levels, and who uses it."
tags: [italy, fire-danger-index]
sources:
  - { id: bollettino, resource: ../corpus/73-italia-bollettino-incendi.html, title: "Bollettino di previsione nazionale incendi boschivi" }
generated: { by: claude-sonnet-5, at: 2026-10-20T00:10:00Z }
---
# Bollettino di previsione nazionale incendi boschivi (Italy)

As required by the Directive on active wildfire fighting of 1 July 2011, signed by the
President of the Council of Ministers, the Dipartimento della Protezione Civile (Italian civil
protection department) produces a national forest-fire forecast bulletin
(Bollettino nazionale di previsione incendi boschivi) every day.[^bollettino] The bulletin takes
into account weather and climatic conditions, vegetation, the physical state and use of the
land, and the territory's morphology and organisation.[^bollettino]

## What the bulletin covers

The bulletin reports a probabilistic forecast scenario of susceptibility to the ignition and
spread of forest fires, structured on three levels: low, medium, high.[^bollettino] It gives an
estimate for up to 24 hours, plus a representation of the trend over the most appropriate
further time scale.[^bollettino]

## Who uses it

This forecasting tool is meant to give the Department's offices information to support the
activities of the State's aerial fleet, so as to organise its management for maximum
effectiveness.[^bollettino] The bulletin is also made available to the administrations
responsible for fire-fighting, to foster an exchange of information and a synergistic
framework of initiatives and actions against forest fires.[^bollettino]

## See also
- [Wildfire prevention and safety reflexes in Italy](wildfire-prevention-safety-italy.md)
- [Météo des forêts (France)](meteo-des-forets-france.md)
- [Fire Weather Index (FWI) System](fire-weather-index.md)

[^bollettino]: Bollettino di previsione nazionale incendi boschivi

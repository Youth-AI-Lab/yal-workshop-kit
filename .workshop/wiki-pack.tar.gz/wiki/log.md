# Wiki update log

<!-- Newest first. One heading per day (## YYYY-MM-DD), one line per change. Kept by the ingest skill. -->

## 2026-11-01

* **Update**: pla-alfa-catalonia.md, section "Contact": 112 comes first; the number 935 617 000 is tied to the map caption, and the page does not say what it covers (corpus/50-catalunya-pla-alfa.html). Added after review.
* **Update**: outdoor-fire-regulation-charente-maritime.md, cooking fires under article 5.2 split into three rules: only mobile stoves and planchas depend on level SÉVÈRE; ground cooking fires are forbidden in massifs at every level; barbecues and stoves need a non-combustible area at every level (corpus/30-charente-maritime-arrete-26EB142.pdf). Added after review.
* **Contradiction**: outdoor-fire-regulation-charente-maritime.md records that article 2.1 of order n° 26EB142 says gas barbecues and planchas are not covered by the order, while article 5.2 of the same order sets rules for gas stoves, planchas and barbecues in massifs (corpus/30-charente-maritime-arrete-26EB142.pdf). Added after review.
* **Contradiction**: wildfire-prevention-france.md records two statements of the same page: 9 out of 10 fires are of human origin and mainly due to carelessness, or half of them are due to carelessness or dangerous behaviour, in a news item dated 23 July 2026 (corpus/20-meteo-france-meteo-des-forets.html). Added after review.
* **Contradiction**: legal-brush-clearing-obligation-france.md records that the mayor is responsible for compliance on linear infrastructure at national level (corpus/22-service-public-debroussaillement.html), while in Bouches-du-Rhône the préfet controls it and the mayor's control does not cover linear networks (corpus/41-bouches-du-rhone-old-dossier-presse.pdf). Added after review.
* **Update**: massif-access-regulation-bouches-du-rhone.md, "one of the départements most exposed" instead of a superlative that the source does not intend (corpus/40-bouches-du-rhone-acces-massifs.html); the exclusion of active firefighting now cites the consolidated order; "flail mowers, harvesters" instead of "brush cutters" in the equipment needing a motor pump (corpus/43-bouches-du-rhone-arrete-acces-consolide.pdf). Added after review.
* **Update**: outdoor-fire-regulation-charente-maritime.md, section on the previous order: document 33 is the prefecture's summary sheet, not the order itself; repeal date now cited from order n° 26EB142; fireworks and waste-burning rules read again on the table of the PDF, because the readable copy loses its columns (corpus/33-charente-maritime-arrete-24EB441-repealed.pdf). Added after review.
* **Update**: wildfire-prevention-ordinance-montoro.md, the Italian wording on fireworks and 1 km is quoted with its literal translation instead of being interpreted (corpus/71-montoro-ordinanza-78-2026.pdf). Added after review.
* **Update**: 2025-eu-wildfire-season.md, the disclaimer and the classification belong to the Knowledge Network page announcing the report, not to the report (corpus/12-eu-advance-report-2025.html). Added after review.
* **Update**: AGENTS.md, the summaries are no longer described as "verified" and "one per source": their `verified` and `status` fields say who checked each one (summaries/index.md). Added after review.

## 2026-10-20

* **Update**: wildfire-prevention-ordinance-montoro.md, definition of the "stero" corrected (apparent volume, corpus/71-montoro-ordinanza-78-2026.pdf). Added after review.
* **Update**: outdoor-fire-regulation-charente-maritime.md, removed a sentence without source and a wrong note on order 24EB441 (corpus/33-charente-maritime-arrete-24EB441-repealed.pdf). Added after review.
* **Contradiction**: 2025-eu-wildfire-season.md, scope of the 2.2 million ha figure: all territories analysed by EFFIS, EU included (corpus/10-jrc-eu-2025-wildfire-season.html), or beyond the EU (corpus/90-echo-record-wildfires-2025.html). Added after the lint.
* **Update**: eu-wildfire-risk-management.md, added the strategy's fire-resilient-landscapes, EFFIS/Copernicus early-warning, firefighting-aircraft-fleet, pre-positioning, Cyprus firefighting hub, population-preparedness, post-fire-recovery and EU-funding-integration measures, and the "no longer seasonal, but structural" framing, from corpus/90-echo-record-wildfires-2025.html.
* **Update**: 2025-eu-wildfire-season.md, added the ECHO account of the 2025 season, from corpus/90-echo-record-wildfires-2025.html.
* **Contradiction**: 2025-eu-wildfire-season.md records the August 2025 Portugal/Spain fires (460,585 ha) as 43% of the EU's total burnt area (corpus/10-jrc-eu-2025-wildfire-season.html), while corpus/90-echo-record-wildfires-2025.html describes the same burnt area as "nearly half" of the EU's total burnt area.
* **Creation**: bollettino-previsione-incendi-italia.md, from corpus/73-italia-bollettino-incendi.html.
* **Update**: wildfire-prevention-safety-italy.md, added "See also" link to bollettino-previsione-incendi-italia.md, from corpus/73-italia-bollettino-incendi.html.
* **Creation**: vesuvius-national-park-2017-wildfires.md, from corpus/72-vesuvio-incendi-2017.docx.
* **Creation**: wildfire-prevention-ordinance-montoro.md, from corpus/71-montoro-ordinanza-78-2026.pdf.
* **Update**: wildfire-prevention-safety-italy.md, added "See also" link to wildfire-prevention-ordinance-montoro.md, from corpus/71-montoro-ordinanza-78-2026.pdf.
* **Creation**: wildfire-prevention-safety-italy.md, from corpus/70-italia-in-caso-di-incendio.html.
* **Update**: wildfire-prevention-france.md, added "See also" link to wildfire-prevention-safety-italy.md, from corpus/70-italia-in-caso-di-incendio.html.
* **Creation**: fire-danger-codes-flanders.md, from corpus/60-vlaanderen-brandgevaarcodes.html.
* **Creation**: belgian-wildfire-network.md, from corpus/60-vlaanderen-brandgevaarcodes.html.
* **Creation**: pla-alfa-catalonia.md, from corpus/50-catalunya-pla-alfa.html.
* **Update**: fire-weather-index.md, added "See also" link to pla-alfa-catalonia.md, from corpus/50-catalunya-pla-alfa.html.
* **Update**: massif-access-regulation-bouches-du-rhone.md, added the fire-risk-level table and its daily determination by the préfet, the full list of access exemptions at "très sévère"/"extrême" risk, the ZAPEF (zone d'accueil du public en forêt) regime, the works authorisation hours by risk level and the required prevention/extinguishing equipment, the three dérogation categories for works (public-safety, agricultural, general-interest/public-utility), the public-event/filming declaration file contents, sanctions (art. R.163-2 code forestier) and recourse procedures, and the abrogation of the 2018 and 2021 orders, from corpus/43-bouches-du-rhone-arrete-acces-consolide.pdf.
* **Contradiction**: massif-access-regulation-bouches-du-rhone.md records the 22 April 2025 order's number as 13-2025-22-04-00011 (corpus/40-bouches-du-rhone-acces-massifs.html), while the consolidated order's own text gives this same order the number 13-2025-04-22-00011 (corpus/43-bouches-du-rhone-arrete-acces-consolide.pdf).
* **Update**: legal-brush-clearing-obligation-france.md, added to the "Bouches-du-Rhône" section the climate/Mediterranean-vegetation vulnerability context, the superseded order of 12 November 2014, the law of 10 July 2023 (promulgation and JO publication dates, strengthened sanctions), the "respected permanently" requirement, and the planned State support for controls on private individuals and linear infrastructure, from corpus/42-bouches-du-rhone-old-arrete-2025.html.
* **Update**: legal-brush-clearing-obligation-france.md, added a "Bouches-du-Rhône" section (new prefectoral order of 15 October 2025, biodiversity-friendly measures, perimeter/depths confirmation, linear-infrastructure clearing-width table, actors, control and sanctions figures, fire-propagation mechanism), from corpus/41-bouches-du-rhone-old-dossier-presse.pdf.
* **Update**: massif-access-regulation-bouches-du-rhone.md, added the forest-coverage figure (175,000 ha, a third of the département) and the département's fire-start/burned-area statistics for 1975-2024, from corpus/41-bouches-du-rhone-old-dossier-presse.pdf.
* **Contradiction**: massif-access-regulation-bouches-du-rhone.md records about 250 fire starts/year and about 1900 ha/year burned with no stated period (corpus/40-bouches-du-rhone-acces-massifs.html), while the dossier de presse records an annual average of more than 228 fire starts and 1,930 ha burned over the period 1975-2024 (corpus/41-bouches-du-rhone-old-dossier-presse.pdf).
* **Creation**: massif-access-regulation-bouches-du-rhone.md, from corpus/40-bouches-du-rhone-acces-massifs.html.
* **Update**: wildfire-prevention-france.md, added "See also" link to massif-access-regulation-bouches-du-rhone.md, from corpus/40-bouches-du-rhone-acces-massifs.html.
* **Update**: outdoor-fire-regulation-charente-maritime.md, added a "Previous order" section summarising the repealed arrêté n° 24EB441 (massif definitions, three geographic sectors, fire-use rules by context), from corpus/33-charente-maritime-arrete-24EB441-repealed.pdf.
* **Contradiction**: outdoor-fire-regulation-charente-maritime.md records that the prefecture's summary sheet dates the repealed order n° 24EB441 to 27 June 2024 with application from 1 July 2024 (corpus/33-charente-maritime-arrete-24EB441-repealed.pdf), while the repeal clause of its successor order n° 26EB142 refers to it as the order of 1 July 2024 (corpus/30-charente-maritime-arrete-26EB142.pdf).
* **Update**: wildfire-prevention-france.md, added 2019 French fire statistics (15,000 ha burned, 80% start under 50 m from dwellings, 90% of destroyed houses on uncleared land) and a fuel-storage prevention tip, from corpus/32-charente-maritime-prevention-page.html.
* **Update**: legal-brush-clearing-obligation-france.md, added the law n° 2023-580 / ministerial order of 6 February 2024 legal basis, the Géoportail OLD map, and the Charente-Maritime figure of 72 communes concerned, from corpus/32-charente-maritime-prevention-page.html.
* **Update**: outdoor-fire-regulation-charente-maritime.md, added the new Valabre vigilance-map platform and 4-sector split, the amending order n° 26EB443 of 24 June 2026 (excludes field-crop harvesting, haymaking, mowing and baling from agricultural-work restrictions), and a new section on the Charente-Maritime PDPFCI 2018/2027 and DDTM contact, from corpus/32-charente-maritime-prevention-page.html.
* **Creation**: outdoor-fire-regulation-charente-maritime.md, from corpus/30-charente-maritime-arrete-26EB142.pdf.
* **Update**: green-waste-burning-ban-france.md, added a "Charente-Maritime" section on the département's broader all-waste burning ban and its contravention-class penalties, from corpus/30-charente-maritime-arrete-26EB142.pdf.
* **Update**: wildfire-prevention-france.md, added "See also" link to outdoor-fire-regulation-charente-maritime.md, from corpus/30-charente-maritime-arrete-26EB142.pdf.
* **Update**: legal-brush-clearing-obligation-france.md, added "See also" link to outdoor-fire-regulation-charente-maritime.md, from corpus/30-charente-maritime-arrete-26EB142.pdf.
* **Contradiction**: green-waste-burning-ban-france.md records a 750 € fine for burning green waste nationally (corpus/23-service-public-dechets-verts.html), while the Charente-Maritime order (corpus/30-charente-maritime-arrete-26EB142.pdf) states different penalties for the same act expressed as contravention classes (1st-class for violating the order, 3rd-class for non-compliance with the departmental sanitary regulation) without giving a euro figure.
* **Creation**: green-waste-burning-ban-france.md, from corpus/23-service-public-dechets-verts.html.
* **Update**: wildfire-prevention-france.md, added "See also" link to green-waste-burning-ban-france.md, from corpus/23-service-public-dechets-verts.html.
* **Creation**: legal-brush-clearing-obligation-france.md, from corpus/22-service-public-debroussaillement.html.
* **Update**: wildfire-prevention-france.md, added "See also" link to legal-brush-clearing-obligation-france.md, from corpus/22-service-public-debroussaillement.html.
* **Creation**: meteo-des-forets-france.md, from corpus/20-meteo-france-meteo-des-forets.html.
* **Creation**: wildfire-prevention-france.md, from corpus/20-meteo-france-meteo-des-forets.html.
* **Creation**: climate-change-wildfire-risk-france.md, from corpus/20-meteo-france-meteo-des-forets.html.
* **Update**: fire-weather-index.md, added "See also" link to meteo-des-forets-france.md, from corpus/20-meteo-france-meteo-des-forets.html.
* **Update**: 2025-eu-wildfire-season.md, added report metadata (publication date, DOI, DRM phases, risk drivers, disclaimer), from corpus/12-eu-advance-report-2025.html.
* **Creation**: fire-weather-index.md, from corpus/11-effis-fire-danger-forecast.html.
* **Update**: effis.md, added "See also" link to fire-weather-index.md, from corpus/11-effis-fire-danger-forecast.html.
* **Creation**: 2025-eu-wildfire-season.md, from corpus/10-jrc-eu-2025-wildfire-season.html.
* **Creation**: effis.md, from corpus/10-jrc-eu-2025-wildfire-season.html.
* **Creation**: eu-wildfire-risk-management.md, from corpus/10-jrc-eu-2025-wildfire-season.html.

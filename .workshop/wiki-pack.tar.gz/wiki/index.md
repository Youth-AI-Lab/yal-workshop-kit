# Topics

<!-- One line per page: * [Title](file.md) - description. Kept up to date by the ingest skill. -->

* [2025 EU wildfire season](2025-eu-wildfire-season.md) - Statistics on the 2025 wildfire season in the EU and in the wider EFFIS-monitored territories.
* [European Forest Fire Information System (EFFIS)](effis.md) - The EU's satellite-based system, managed by the JRC, for monitoring and mapping wildfires across Europe and neighbouring regions.
* [EU wildfire risk management](eu-wildfire-risk-management.md) - EU policy framework and resources (rescEU, the Civil Protection Mechanism) for preventing, preparing for, and responding to wildfires.
* [Fire Weather Index (FWI) System](fire-weather-index.md) - The Canadian FWI System used by EFFIS to compute fire danger, its classes, and related indices.
* [Météo des forêts (France)](meteo-des-forets-france.md) - Météo-France's daily forecast of forest-fire danger levels by département, and what it does and does not tell the public.
* [Wildfire prevention and safety reflexes in France](wildfire-prevention-france.md) - Causes of forest fires in France, recommended prevention behaviours, what to do if a fire starts, and préfecture restrictions.
* [Climate change and wildfire risk in France](climate-change-wildfire-risk-france.md) - Projected impact of climate change on forest-fire risk and the fire season in France.
* [Legal obligation to clear brush (débroussaillement) in France](legal-brush-clearing-obligation-france.md) - Who must clear brush around buildings in France, the required depths, timing, exceptions, and the penalties for non-compliance.
* [Ban on burning green waste in France](green-waste-burning-ban-france.md) - The French ban on burning garden/green waste, what counts as green waste, alternatives, exceptions, and penalties.
* [Outdoor fire use regulation in Charente-Maritime (arrêté n° 26EB142)](outdoor-fire-regulation-charente-maritime.md) - The Charente-Maritime prefectoral order on outdoor fire use, leisure fires, fireworks, waste burning and vigilance levels, in force from 1 May 2026.
* [Access and works regulation in Bouches-du-Rhône forest massifs](massif-access-regulation-bouches-du-rhone.md) - Bouches-du-Rhône's daily access restrictions to forest massifs and regulation of works liable to start fires, from 1 June to 30 September.
* [Pla Alfa (Catalonia)](pla-alfa-catalonia.md) - Catalonia's Pla Alfa operational plan establishing 5 daily forest-fire danger levels at municipal scale, and the activity restrictions and civil-protection consequences triggered at each level.
* [Fire-danger colour codes in Flanders (Belgium)](fire-danger-codes-flanders.md) - The four fire-danger colour codes (green/yellow/orange/red) used in Flemish nature and forest areas, how they are set, and the precautions attached to each.
* [Belgian Wildfire Network](belgian-wildfire-network.md) - A network bringing together science, operational expertise and policy to prepare Belgium for nature fires across all its regions.
* [Wildfire prevention and safety reflexes in Italy](wildfire-prevention-safety-italy.md) - Italian civil protection advice on preventing forest fires and on what to do while a fire is under way.
* [Bollettino di previsione nazionale incendi boschivi (Italy)](bollettino-previsione-incendi-italia.md) - The Italian civil protection department's daily national forest-fire forecast bulletin: what it covers, its three danger levels, and who uses it.
* [Wildfire-prevention ordinance in Montoro (Ordinanza n. 78/2026)](wildfire-prevention-ordinance-montoro.md) - The Montoro (Campania) mayoral ordinance applying wildfire-prevention measures for the 2026 high-danger period, its bans, obligations and penalties.
* [2017 wildfires in the Vesuvius National Park](vesuvius-national-park-2017-wildfires.md) - Extent and severity of the July–August 2017 fires in the Parco Nazionale del Vesuvio, their effect on future fire risk, and the post-fire restoration plan.

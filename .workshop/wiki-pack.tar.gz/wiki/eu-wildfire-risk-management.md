---
type: Topic
title: "EU wildfire risk management"
description: "EU policy framework and resources (rescEU, the Civil Protection Mechanism) for preventing, preparing for, and responding to wildfires."
tags: [europe, policy, wildfires]
sources:
  - { id: jrc2025, resource: ../corpus/10-jrc-eu-2025-wildfire-season.html, title: "2025 was EU's most destructive wildfire season on record" }
  - { id: echo2026, resource: ../corpus/90-echo-record-wildfires-2025.html, title: "Record number of wildfires in 2025 calls for stronger EU action" }
generated: { by: claude-sonnet-5, at: 2026-10-20T11:15:00Z }
---
# EU wildfire risk management

On 25 March 2026, the European Commission adopted a new integrated approach to wildfire risk
management, covering prevention, preparedness, response and recovery.[^jrc2025] The
Communication proposes a range of concrete actions to promote a more holistic and impactful
approach to wildfire management.[^jrc2025]

This strategy promotes fire-resilient landscapes through sustainable land management and
nature restoration, strengthens early warning and monitoring through EFFIS and Copernicus, and
boosts firefighting capacity through an EU firefighting aircraft fleet, the pre-positioning of
firefighters, and a new European firefighting hub in Cyprus.[^echo2026] It also addresses
population preparedness, post-fire recovery, and the integration of wildfire risk into EU
funding frameworks.[^echo2026] With this strategy, Europe is adapting to a wildfire risk that is
no longer seasonal, but structural.[^echo2026]

The Commission is also continuously strengthening its broad range of firefighting tools to
better respond to the growing threat of wildfires in Europe.[^jrc2025] The EU Civil Protection
Mechanism (UCPM) pools resources from the 27 EU Member States and 10 UCPM Participating States,
including firefighting personnel and equipment.[^jrc2025]

Each summer, the Commission finances the strategic prepositioning of firefighters in high-risk
locations and the stand-by availability of a joint firefighting fleet known as
rescEU.[^jrc2025] Considering several record-breaking wildfire seasons across Europe, rescEU is
being continuously reinforced to make sufficient aerial means available every year.[^jrc2025]

For the longer term, the Commission has allocated significant financial resources to acquire 12
new firefighting planes, to be based in Portugal, Spain, France, Italy, Croatia, and Greece, and
5 helicopters, to be based in Slovakia, Czechia, and Romania; these aircraft will form the
permanent rescEU fleet.[^jrc2025] The first helicopter was delivered earlier in 2026, and the
first planes will be delivered from 2028 onwards.[^jrc2025]

## See also
- [2025 EU wildfire season](2025-eu-wildfire-season.md)
- [European Forest Fire Information System (EFFIS)](effis.md)

[^jrc2025]: 2025 was EU's most destructive wildfire season on record
[^echo2026]: Record number of wildfires in 2025 calls for stronger EU action

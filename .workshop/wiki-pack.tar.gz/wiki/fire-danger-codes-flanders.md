---
type: Topic
title: "Fire-danger colour codes in Flanders (Belgium)"
description: "The four fire-danger colour codes (green/yellow/orange/red) used in Flemish nature and forest areas, how they are set, and the precautions attached to each."
tags: [belgium, flanders, fire-danger-index]
sources:
  - { id: anbcodes, resource: ../corpus/60-vlaanderen-brandgevaarcodes.html, title: "Brandpreventie in natuur- en bosgebieden op basis van kleurcodes" }
generated: { by: claude-sonnet-5, at: 2026-10-20T12:00:00Z }
---
# Fire-danger colour codes in Flanders (Belgium)

The fire-danger season in Flanders runs from 1 March to 30 September.[^anbcodes] During this
period, the danger of nature fires is evaluated weekly to daily, based on the Fire Weather
Index (FWI) and other indices of the European Forest Fire Information System (EFFIS), and on
detailed weather forecasts from the Royal Meteorological Institute of Belgium (KMI).[^anbcodes]
This evaluation is translated into one of four successive fire-danger codes, expressed as a
colour code (green – yellow – orange – red), linked to the level of monitoring and readiness of
fire services, nature managers and other emergency services.[^anbcodes]

The codes are set per province and are valid for all nature and forest areas managed by
Natuur en Bos (ANB) located in that province.[^anbcodes] The fire danger in nature and forest
areas of other public authorities (provinces, municipalities) or private owners is considered
similarly comparable, and the same caution is advised there.[^anbcodes]

## Fire sensitivity of vegetation

Fire sensitivity depends on the time of year and the vegetation present, e.g. dead plant
remains of grasses, ferns, reeds at the end of winter, or dry vegetation types such as heath
and conifer forest in summer.[^anbcodes] Heathland and conifer forest are the most
fire-sensitive areas in Flanders; deciduous forest is much less fire-sensitive, unless during
prolonged drought and sustained high temperatures.[^anbcodes] Plots with a higher share of dead
or dry vegetation, due to causes such as pest outbreaks, disease or a strongly altered
groundwater table, can become very fire-prone depending on weather conditions; an example given
is a spruce stand affected by the bark beetle *Ips typographus*.[^anbcodes] Crops left standing
and drying in the field over winter, such as fauna fields or giant miscanthus (*Miscanthus
giganteus*) plots, also have a higher fire sensitivity at the end of winter.[^anbcodes]

## The four codes

**Green – little danger.** There is no particular danger of nature fire; if a fire breaks out,
the fire brigade responds at normal strength.[^anbcodes]

**Yellow – danger.** Nature is starting to dry out, increasing the risk of nature fire; visitors
are asked to be careful, not to smoke in nature and forest areas and not to light fires; nature
managers and fire services are vigilant; if a fire breaks out, the fire brigade responds at an
adapted strength; the manning of fire towers depends on the risk assessment by Natuur en Bos and
the fire services.[^anbcodes]

**Orange – high danger.** It is very dry and fire-prone in nature; visitors are asked to be
careful, not to smoke and not to light fires, and not to leave children unsupervised on site;
nature managers and fire services are very vigilant; if a fire breaks out, the fire brigade
responds with reinforcements, deploying more equipment and manpower; the manning of fire towers
depends on the risk assessment by Natuur en Bos and the fire services.[^anbcodes]

**Red – acute high danger.** It is extremely dry and acutely fire-prone in nature; for safety
reasons, access to nature and forest areas is discouraged; visitors are asked to be careful, not
to smoke and not to light fires in or near nature and forest areas, and to keep an eye on
children; nature managers and fire services are extra vigilant; if a fire breaks out, the fire
brigade always responds with heavy equipment, with extra equipment and manpower deployed; fire
towers are permanently manned during the day, unless otherwise agreed between Natuur en Bos and
the fire services based on local circumstances.[^anbcodes]

## Communication to visitors

During fire-sensitive periods, the fire-danger code can be checked daily on municipal
websites.[^anbcodes] At the access points of a number of areas, special information boards
indicate the fire-danger code with an arrow, or refer visitors via a QR code to the Natuur en
Bos website.[^anbcodes] As a visitor, it is at all times forbidden to light a fire or to throw
cigarette butts on the ground.[^anbcodes]

## See also
- [Fire Weather Index (FWI) System](fire-weather-index.md)
- [European Forest Fire Information System (EFFIS)](effis.md)
- [Belgian Wildfire Network](belgian-wildfire-network.md)
- [Pla Alfa (Catalonia)](pla-alfa-catalonia.md)
- [Météo des forêts (France)](meteo-des-forets-france.md)

[^anbcodes]: Brandpreventie in natuur- en bosgebieden op basis van kleurcodes

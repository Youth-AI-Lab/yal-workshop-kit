<!-- Claude Code reads CLAUDE.md, not AGENTS.md. The line below imports AGENTS.md, the schema
     of the wiki (OpenCode reads AGENTS.md directly). AGENTS.md is the file to edit. -->
@AGENTS.md

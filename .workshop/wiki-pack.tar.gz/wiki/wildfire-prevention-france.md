---
type: Topic
title: "Wildfire prevention and safety reflexes in France"
description: "Causes of forest fires in France, recommended prevention behaviours, what to do if a fire starts, and préfecture restrictions."
tags: [france, prevention, what-to-do]
sources:
  - { id: meteoforets, resource: ../corpus/20-meteo-france-meteo-des-forets.html, title: "Météo des forêts" }
  - { id: cm-prevention-page, resource: ../corpus/32-charente-maritime-prevention-page.html, title: "Prévention des incendies de forêt, d'espaces naturels et agricoles" }
generated: { by: claude-sonnet-5, at: 2026-10-20T00:00:00Z }
---
# Wildfire prevention and safety reflexes in France

9 out of 10 fires are of human origin, mainly due to carelessness.[^meteoforets] In a related
article on the same source, Météo-France specifies that half of these human-origin fires are
due to carelessness or dangerous behaviour.[^meteoforets] A prefecture source similarly states
that nine out of ten fires are of human origin.[^cm-prevention-page] It also states that in 2019,
15,000 hectares of forest and vegetation burned in France, roughly one and a half times the area
of Paris, and that half of these forest fires were due to carelessness and could have been
avoided through simple prevention and protection measures.[^cm-prevention-page] The same source
states that 80% of forest fires start less than 50 metres from dwellings, and that, according to
feedback from past fires, 90% of houses destroyed during forest fires were on land that had not
been cleared of brush, or poorly so.[^cm-prevention-page]

## Preventing fire starts

- **Barbecues**: have barbecues at home, on a terrace, away from vegetation.[^meteoforets]
- **Cigarettes**: put cigarette butts out in an ashtray.[^meteoforets]
- **Work generating sparks**: do such work away from lawns and dry grass, and keep a fire
  extinguisher within reach in case a fire starts.[^meteoforets]
- **Fuel storage**: do not store combustible materials (firewood, paint or solvents, gas or fuel
  tanks) near houses.[^cm-prevention-page]

## What to do if a fire starts

- **Alert**: anyone who witnesses the start of a fire should call 112, 18, or 114 (for the
  hearing-impaired) and try to locate the fire.[^meteoforets]
- **Shelter**: take shelter in a dwelling with cleared vegetation around it while waiting for
  emergency services; a car is not a safe shelter because it could burn.[^meteoforets]
- **Stay informed**: keep informed of the situation and follow instructions from emergency
  services or the mairie.[^meteoforets]

## Préfecture restrictions

Access to and movement in woods, forests, moorlands and garrigues can be discouraged or even
banned for vehicles and pedestrians at certain times.[^meteoforets] Barbecues, fireworks and any
use of fire can also be banned.[^meteoforets] Agricultural and forestry work, and work that can
generate sparks (shredders, brushcutters, chainsaws, welders, etc.), can be regulated or
banned.[^meteoforets] Failing to follow the prevention instructions issued by public authorities
exposes a person to a 4th-class fine of 750 €.[^meteoforets] People should check the website of
the préfecture of their home or holiday location for these possible restrictions.[^meteoforets]

## See also
- [Météo des forêts (France)](meteo-des-forets-france.md)
- [Legal obligation to clear brush (débroussaillement) in France](legal-brush-clearing-obligation-france.md)
- [Ban on burning green waste in France](green-waste-burning-ban-france.md)
- [Outdoor fire use regulation in Charente-Maritime (arrêté n° 26EB142)](outdoor-fire-regulation-charente-maritime.md)
- [Access and works regulation in Bouches-du-Rhône forest massifs](massif-access-regulation-bouches-du-rhone.md)
- [Wildfire prevention and safety reflexes in Italy](wildfire-prevention-safety-italy.md)

[^meteoforets]: Météo des forêts
[^cm-prevention-page]: Prévention des incendies de forêt, d'espaces naturels et agricoles

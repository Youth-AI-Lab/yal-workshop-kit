---
type: Topic
title: "Wildfire-prevention ordinance in Montoro (Ordinanza n. 78/2026)"
description: "The Montoro (Campania) mayoral ordinance applying wildfire-prevention measures for the 2026 high-danger period, its bans, obligations and penalties."
tags: [campania, italy, regulation, prevention]
sources:
  - { id: ord-78, resource: ../corpus/71-montoro-ordinanza-78-2026.pdf, title: "Ordinanza n. 78 del 12/06/2026 - prevenzione del rischio incendi boschivi" }
generated: { by: claude_code, at: 2026-11-01T00:20:18Z }
---
# Wildfire-prevention ordinance in Montoro (Ordinanza n. 78/2026)

Decreto Dirigenziale n. 212 of 9 June 2026 of the Regione Campania declared a period of grave
pericolosità (high danger) for forest fires across the whole territory of the Regione Campania,
valid from 15 June 2026 to 30 September 2026.[^ord-78] On that basis, the Mayor of Montoro
(province of Avellino, Campania) issued Ordinanza n. 78 of 12 June 2026, applying
wildfire-prevention measures for that period.[^ord-78]

## Bans recalled for the high-danger period (15 June – 30 September 2026)

- Ban on burning agricultural and forestry vegetal residue during the period of maximum
  fire-risk declared by the Region (art. 182, comma 6-bis, D.Lgs. n. 152/2006).[^ord-78]
- Ban on burning stubble and weeds, including on uncultivated land, from 1 June to
  20 September (art. 25, c.1 lett. f, Legge regionale n. 26/2012).[^ord-78]
- Ban on lighting open-air fires in woods and within 100 m of them, and in pastures
  (art. 75, c. 1 and 3, Regolamento regionale n. 3/2017).[^ord-78]
- Ban, in woods and pastures, on using engines or stoves that produce sparks or embers; using
  flame or electric tools to cut metal; blasting mines; smoking or doing anything else that could
  create a fire hazard, such as throwing lit matches or cigarettes, or parking vehicles on unpaved
  roads within wooded areas (except service vehicles and agro-silvo-pastoral activities)
  (art. 75, c. 4, Regolamento regionale n. 3/2017).[^ord-78]
- Ban on fireworks, rockets of any kind and/or paper hot-air balloons ("flying lanterns") with
  open flames, and other pyrotechnic articles, "a una distanza non inferiore a 1 km dalle superfici
  boscate e pascoli" (literally: "at a distance not less than 1 km from woods and pastures"),
  unless an exception is authorised by a mayoral ordinance for public events with
  fire-prevention measures in place; violations are sanctioned under art. 10, c. 6, of
  Legge n. 353/2000.[^ord-78]

## Obligations ordered

1. **Infrastructure managers** (railways, ANAS, water-service operators, the motorway company,
   the Provincia, Consorzi di Bonifica, and competent municipal offices) must clean verges,
   ditches and embankments under their responsibility, removing dry grass, vegetal residue,
   brambles, deadwood and waste along their infrastructure bordering or near wooded areas, to
   create protection strips (art. 75, c. 14, Regolamento regionale n. 3/2017); road managers
   must also periodically prune trees encroaching on the roadway so firefighting vehicles can
   pass.[^ord-78]
2. **Urban-rural interface areas and tourist/accommodation facilities**: owners of such areas and
   managers of campsites, tourist villages, residential centres, hotels and other accommodation
   facilities exposed to fire fronts must maintain protection strips and clear vegetation
   (herbaceous and shrub vegetation, brambles, deadwood) and ignition sources within a radius of
   at least 20 metres around the settlement (art. 75, c. 15, Regolamento regionale n. 3/2017), and
   must have evacuation plans with assembly points kept constantly free and accessible, and
   suitable fire-defence systems.[^ord-78]
3. **Uncultivated and fallow land**: owners, tenants and occupants of uncultivated, abandoned or
   fallow land must create protective strips free of vegetal residue, at least 5 metres wide,
   along the whole perimeter of their land. Owners of land fronting roads bordering or near
   wooded areas must keep the verges and embankments under their responsibility clear of
   vegetation (art. 75, c. 14-bis, Regolamento regionale n. 3/2017). Compliance with conditionality
   rules (BCAA 6, art. 3, c. 4, lett. a, D.M. n. 2588 of 20/03/2020, and Delibera di Giunta
   regionale n. 341 of 09/07/2020) is also recalled.[^ord-78]
4. **Cultivated fields**: owners, tenants and occupants of cereal and forage fields must, after
   harvesting or mowing, create a ploughed protective strip free of vegetal residue, at least 5
   metres wide, around the perimeter and inside the cultivated area, sufficient to prevent fire
   spreading to surrounding land. The absolute ban on burning agricultural and forestry residue
   during the region's maximum-risk period (art. 182, c. 6-bis, D.Lgs. n. 152/2006) and the ban on
   burning stubble and weeds from 1 June to 20 September (art. 25, c.1 lett. f, Legge regionale
   n. 26/2012) are recalled.[^ord-78]
5. **High explosive/flammability-risk activities** (fireworks factories, fuel depots, chemical or
   plastics depots/factories, etc.) located in areas defined by art. 2 of Legge n. 353/2000 must
   report to the Comune their site and branch locations, the contact details of the person
   responsible for the activity and for safety (available 24/7), and must produce a copy of their
   fire-emergency plan, valid for outdoor areas too. Along the perimeter adjacent to shrub, wooded
   or pasture areas, they must take all precautionary measures, including protection strips. The
   Comune forwards this data to the Regione Campania's Protezione Civile for the Sala Operativa
   Unificata Permanente. Building furnaces, depots or factories of any kind liable to cause fire
   or explosion inside woods, or less than 100 m from them, is banned (art. 76, Regolamento
   regionale n. 3/2017).[^ord-78]
6. **Wooded areas**: owners, tenants, and public or private bodies responsible for managing,
   maintaining and conserving woods must restore and clear firebreaks ("viali parafuoco"),
   particularly along the boundary with forest trails, roads, motorways, railways, cultivated
   land, pastures, and uncultivated or shrub land, and must prune trees along the wood's perimeter
   strip up to no more than the lower third of their height, following the regional forest plan;
   these prevention activities are subject to simplified procedures.[^ord-78]
7. **Burning of vegetal residue outside the period of maximum fire danger**: burning of residue
   from mowing, pruning or clearing, done on site at least 50 m from woods, is allowed only under
   these conditions: burning is allowed only from 9:00 to 15:00, except on public holidays;
   material must be dried beforehand and gathered in small piles, totalling no more than 3 "steri"
   per hectare per day (a "stero" being the unit of apparent volume used for timber, equal to one
   cubic metre including the empty spaces); no more than 5 piles of purely vegetal material may be burned per plot; piles must be
   at least 100 m from third parties' dwellings and at least 30 m from public roads, and smoke
   must not reach dwellings, roads or built-up areas (if it does because of sudden wind or
   weather, the fire must be put out immediately); any pile still smoking after the allowed hours
   must be extinguished; constant supervision by the producer, tenant or a trusted adult is
   required throughout, and leaving the site before the fire and embers are fully extinguished is
   strictly forbidden; and where dwellings or similar buildings are closer than the 100 m distance,
   vegetal residue, including from small gardens, cannot be burned and must instead be buried or
   covered for composting.[^ord-78]

## Enforcement and penalties

All police bodies, the Polizia Locale and the competent territorial entities are tasked with
monitoring compliance with the ordinance and with the laws and regulations on forest fires and the
urban-rural interface.[^ord-78] Failure to comply with the bans and obligations listed triggers the
sanctions provided by state and regional law, as well as criminal sanctions under articles 423,
423-bis, 449 and 650 of the Codice Penale where applicable.[^ord-78] Any other violation of the
prevention measures for which no specific sanction already exists is punished with an
administrative fine of between 25 and 500 euros, under art. 7-bis of D.Lgs. n. 267/2000.[^ord-78]
For anything not covered by the ordinance, the regional provision declaring the period of maximum
forest-fire danger (issued under Legge regionale n. 12/2017 and Regolamento regionale n. 3/2017)
applies.[^ord-78]

## Effective date, publication and appeal

The ordinance is immediately executive and is made public through the Albo Pretorio, the
Comune di Montoro's website, and posters displayed across the municipal territory.[^ord-78] It is
transmitted to the Polizia Municipale, the Giunta comunale, the Comune's department heads, the
Carabinieri (Compagnia di Solofra, Stazione di Montoro, Stazione Forestale di Forino), the Polizia
Stradale of Avellino, the Guardia di Finanza, the president of the Parco dei Monti Picentini, ANAS,
Ferrovie di Napoli, the Consorzio di Bonifica integrale Comprensorio Sarno, the Provincia di
Avellino, and local civil-protection and AIB volunteer associations, and for information to the
Regional Civil Protection, the Prefettura di Avellino, the Questura di Avellino, the Vigili del
Fuoco and Carabinieri of Avellino.[^ord-78] An appeal against the ordinance can be lodged with the
Tribunale Amministrativo Regionale per la Campania, under Decreto Legislativo n. 104 of 2 July 2010
(Codice del processo amministrativo).[^ord-78]

## See also
- [Wildfire prevention and safety reflexes in Italy](wildfire-prevention-safety-italy.md)

[^ord-78]: Ordinanza n. 78 del 12/06/2026 - prevenzione del rischio incendi boschivi

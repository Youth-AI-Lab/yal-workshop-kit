# Graph Report - wiki  (2026-11-02)

## Corpus Check
- Corpus is ~16,471 words - fits in a single context window. You may not need a graph.

## Summary
- 108 nodes · 192 edges · 8 communities
- Extraction: 89% EXTRACTED · 11% INFERRED · 0% AMBIGUOUS · INFERRED: 22 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Danger scales: FWI, France, Flanders, Catalonia
- EU 2025 season and monitoring
- Wiki log, contradictions, Charente-Maritime orders
- French fire rules and penalties
- Massif orders, risk levels and works
- Brush clearing (OLD) in France
- Italy: alerts, Vesuvius, bulletin
- Montoro ordinance and fireworks

## God Nodes (most connected - your core abstractions)
1. `Arrêté préfectoral n° 26EB142 (in force 1 May 2026)` - 16 edges
2. `Wiki update log` - 15 edges
3. `Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access` - 14 edges
4. `European Forest Fire Information System (EFFIS)` - 12 edges
5. `Wildfire prevention and safety reflexes in France` - 10 edges
6. `Wildfire-prevention ordinance in Montoro (Ordinanza n. 78/2026)` - 10 edges
7. `Prefectoral order of 22 April 2025 on massif access, 1 June to 30 September (partially revised 9 July 2026, consolidated version published)` - 9 edges
8. `Météo des forêts (France)` - 8 edges
9. `2025 EU wildfire season` - 7 edges
10. `Fire Weather Index (FWI) System` - 7 edges

## Surprising Connections (you probably didn't know these)
- `Bollettino di previsione nazionale incendi boschivi (Italy)` --semantically_similar_to--> `Météo des forêts (France)`  [INFERRED] [semantically similar]
  bollettino-previsione-incendi-italia.md → meteo-des-forets-france.md
- `Wildfire prevention and safety reflexes in France` --semantically_similar_to--> `Wildfire prevention and safety reflexes in Italy`  [INFERRED] [semantically similar]
  wildfire-prevention-france.md → wildfire-prevention-safety-italy.md
- `France 2019: 15,000 ha burned; 80% of fires start under 50 m from dwellings; 90% of destroyed houses on uncleared land` --conceptually_related_to--> `Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access`  [INFERRED]
  wildfire-prevention-france.md → legal-brush-clearing-obligation-france.md
- `Montoro protection strips (20 m around settlements, 5 m around land)` --semantically_similar_to--> `Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access`  [INFERRED] [semantically similar]
  wildfire-prevention-ordinance-montoro.md → legal-brush-clearing-obligation-france.md
- `Pla Alfa five municipal danger levels (0 low to 4 extreme), updated at 00:00 and 9:30` --semantically_similar_to--> `Bouches-du-Rhône four daily fire-risk levels (faible/léger/modéré, sévère, très sévère, extrême)`  [INFERRED] [semantically similar]
  pla-alfa-catalonia.md → massif-access-regulation-bouches-du-rhone.md

## Hyperedges (group relationships)
- **Source contradictions recorded by ingest/lint**: 2025_eu_wildfire_season_scope_contradiction, 2025_eu_wildfire_season_august_share_contradiction, massif_access_regulation_bouches_du_rhone_order_number_contradiction, massif_access_regulation_bouches_du_rhone_fire_start_stats_contradiction, outdoor_fire_regulation_charente_maritime_repeal_date_contradiction, green_waste_burning_ban_france_penalty_contradiction, outdoor_fire_regulation_charente_maritime_gas_barbecue_contradiction, wildfire_prevention_france_carelessness_contradiction, legal_brush_clearing_obligation_france_mayor_vs_prefet_contradiction [EXTRACTED 1.00]
- **EU wildfire monitoring and response system**: effis, effis_jrc, effis_copernicus_emergency_management_service, eu_wildfire_risk_management_integrated_approach_2026, eu_wildfire_risk_management_resceu, eu_wildfire_risk_management_ucpm [INFERRED 0.85]
- **Daily fire-danger scales compared in the wiki**: fire_weather_index_six_danger_classes, meteo_des_forets_france_four_danger_levels, fire_danger_codes_flanders_four_colour_codes, pla_alfa_catalonia_five_levels, bollettino_previsione_incendi_italia_three_danger_levels, outdoor_fire_regulation_charente_maritime_six_vigilance_levels, massif_access_regulation_bouches_du_rhone_fire_risk_levels [INFERRED 0.75]

## Communities (8 total, 0 thin omitted)

### Community 0 - "Danger scales: FWI, France, Flanders, Catalonia"
Cohesion: 0.15
Nodes (19): Belgian Wildfire Network, Climate change and wildfire risk in France, +4 °C France by 2100 scenario (fire risk nationwide, season 1 to 2 months longer in some regions), Fire-danger colour codes in Flanders (Belgium), Flemish four colour codes (green, yellow, orange, red), set per province, 1 March to 30 September, Royal Meteorological Institute of Belgium (KMI), Natuur en Bos (ANB), Fire Weather Index (FWI) System (+11 more)

### Community 1 - "EU 2025 season and monitoring"
Cohesion: 0.20
Nodes (15): 2025 EU wildfire season, Advance Report on Forest Fires in Europe, Middle East and North Africa 2025 (12 October 2026), 2 242 195 ha burnt in all EFFIS territories in 2025 (Ukraine almost 30%), August 2025 heatwave: 22 very large fires in Portugal and Spain (460 585 ha), 1 079 538 ha burnt in the EU in 2025 (7 783 fires, 25 of 27 Member States), Natura 2000 (39% of EU burnt area, 424 023 ha in 2025), European Forest Fire Information System (EFFIS), Copernicus Emergency Management Service (+7 more)

### Community 2 - "Wiki log, contradictions, Charente-Maritime orders"
Cohesion: 0.21
Nodes (15): Contradiction: August fires 43% vs nearly half of EU burnt area, Contradiction: scope of the 2.2 million ha figure (EU included or beyond the EU), Contradiction: 750 EUR national fine vs contravention classes in Charente-Maritime, Wiki update log, Contradiction: ~250 fire starts / 1900 ha per year vs >228 / 1,930 ha (1975-2024), Arrêté préfectoral n° 24EB441 (repealed), Arrêté préfectoral n° 26EB142 (in force 1 May 2026), Arrêté n° 26EB443 of 24 June 2026 (excludes harvesting, haymaking, mowing, baling) (+7 more)

### Community 3 - "French fire rules and penalties"
Cohesion: 0.23
Nodes (14): Ban on burning green waste in France, 750 EUR fine for burning green waste (also for selling an incinerator), Code de l'environnement (L541-21-1, R541-78), Legal obligation to clear brush (débroussaillement) in France, Access and works regulation in Bouches-du-Rhône forest massifs, Bouches-du-Rhône: 90% of fire starts of human origin, half due to carelessness, Outdoor fire use regulation in Charente-Maritime (arrêté n° 26EB142), DDTM de la Charente-Maritime (contact point of the prevention page) (+6 more)

### Community 4 - "Massif orders, risk levels and works"
Cohesion: 0.19
Nodes (13): Code forestier, Bouches-du-Rhône four daily fire-risk levels (faible/léger/modéré, sévère, très sévère, extrême), Prefectoral order of 22 April 2025 on massif access, 1 June to 30 September (partially revised 9 July 2026, consolidated version published), Contradiction: order number 13-2025-22-04-00011 vs 13-2025-04-22-00011, Bouches-du-Rhône forest-fire protection plan (PDPFCI, 8 January 2024), Article R.163-2 Code forestier (penalties), Works liable to start fires: all day, 5h-13h at sévère, forbidden at très sévère and extrême; hose, extinguishers or motor pump, Direction générale de la sécurité civile et de la gestion des crises (DGSCGC) (+5 more)

### Community 5 - "Brush clearing (OLD) in France"
Cohesion: 0.26
Nodes (11): Bouches-du-Rhône OLD prefectoral order of 15 October 2025 (replaces the order of 12 November 2014), DDTM des Bouches-du-Rhône (direction départementale des territoires et de la mer), Law n° 2023-580 of 10 July 2023 (fire-risk prevention, stronger sanctions), Bouches-du-Rhône clearing widths for linear infrastructure (20 m main roads and railways, 10 m communal roads, 5 to 10 m power lines), Contradiction: mayor (national rule) vs préfet (Bouches-du-Rhône) controls brush clearing on linear infrastructure, Ministerial order of 6 February 2024 (woods and forests exposed to fire risk), Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access, Office National des Forêts (ONF) (+3 more)

### Community 6 - "Italy: alerts, Vesuvius, bulletin"
Cohesion: 0.22
Nodes (10): Bollettino di previsione nazionale incendi boschivi (Italy), Dipartimento della Protezione Civile (Italy), Directive on active wildfire fighting of 1 July 2011, Bollettino three levels (low, medium, high), forecast up to 24 hours, 2017 wildfires in the Vesuvius National Park, 3194 ha damaged in July/August 2017 (about 80% of the park's woods; 374 ha high severity), Post-fire restoration plan (650 ha priority, two pilot projects on 80 ha, 1.2 M EUR), French fire alert numbers (112, 18, 114); a car is not a safe shelter (+2 more)

### Community 7 - "Montoro ordinance and fireworks"
Cohesion: 0.36
Nodes (8): Fireworks forbidden in massifs; from SÉVÈRE only at sea or on the foreshore; all forbidden from TRÈS SÉVÈRE, Wildfire-prevention ordinance in Montoro (Ordinanza n. 78/2026), Decreto Dirigenziale n. 212 of 9 June 2026 (Regione Campania high-danger period, 15 June to 30 September 2026), Montoro penalties: administrative fine of 25 to 500 EUR; Codice Penale 423, 423-bis, 449, 650, Montoro fireworks and flying-lantern ban: not less than 1 km from woods and pastures, Legge n. 353/2000, Montoro protection strips (20 m around settlements, 5 m around land), Regolamento regionale n. 3/2017 (Campania)

## Knowledge Gaps
- **15 isolated node(s):** `Natura 2000 (39% of EU burnt area, 424 023 ha in 2025)`, `Expert Group on Forest Fires (43 countries)`, `European firefighting hub in Cyprus`, `Royal Meteorological Institute of Belgium (KMI)`, `+4 °C France by 2100 scenario (fire risk nationwide, season 1 to 2 months longer in some regions)` (+10 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 17 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Wiki update log` connect `Wiki log, contradictions, Charente-Maritime orders` to `Danger scales: FWI, France, Flanders, Catalonia`, `EU 2025 season and monitoring`, `French fire rules and penalties`, `Massif orders, risk levels and works`, `Brush clearing (OLD) in France`, `Montoro ordinance and fireworks`?**
  _High betweenness centrality (0.285) - this node is a cross-community bridge._
- **Are the 2 inferred relationships involving `Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access` (e.g. with `France 2019: 15,000 ha burned; 80% of fires start under 50 m from dwellings; 90% of destroyed houses on uncleared land` and `Montoro protection strips (20 m around settlements, 5 m around land)`) actually correct?**
  _`Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access` has 2 INFERRED edges - model-reasoned connections that need verification._
- **What connects `Natura 2000 (39% of EU burnt area, 424 023 ha in 2025)`, `Expert Group on Forest Fires (43 countries)`, `European firefighting hub in Cyprus` to the rest of the system?**
  _15 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Why does `Arrêté préfectoral n° 26EB142 (in force 1 May 2026)` connect `Wiki log, contradictions, Charente-Maritime orders` to `French fire rules and penalties`, `Massif orders, risk levels and works`, `Brush clearing (OLD) in France`, `Montoro ordinance and fireworks`?**
  _High betweenness centrality (0.169) - this node is a cross-community bridge._
- **Why does `Météo des forêts (France)` connect `Danger scales: FWI, France, Flanders, Catalonia` to `French fire rules and penalties`, `Massif orders, risk levels and works`, `Italy: alerts, Vesuvius, bulletin`?**
  _High betweenness centrality (0.168) - this node is a cross-community bridge._
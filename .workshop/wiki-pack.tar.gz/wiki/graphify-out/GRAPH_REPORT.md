# Graph Report - wiki  (2026-11-06)

## Corpus Check
- Corpus is ~16,917 words - fits in a single context window. You may not need a graph.

## Summary
- 111 nodes · 204 edges · 8 communities
- Extraction: 89% EXTRACTED · 11% INFERRED · 0% AMBIGUOUS · INFERRED: 22 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Brush clearing, massif access and the wiki log
- Danger scales: FWI, France, Flanders, Catalonia
- EU 2025 season and monitoring
- Waste burning and Charente-Maritime orders
- Italy: bulletin, Vesuvius, alert numbers
- Montoro ordinance and fireworks
- French prevention pages and human causes
- Daily risk levels and services in France

## God Nodes (most connected - your core abstractions)
1. `Wiki update log` - 21 edges
2. `Arrêté préfectoral n° 26EB142 (in force 1 May 2026)` - 16 edges
3. `Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access` - 15 edges
4. `European Forest Fire Information System (EFFIS)` - 12 edges
5. `Prefectoral order of 22 April 2025 on massif access, 1 June to 30 September, extendable by prefectoral order in exceptional circumstances (partially revised 9 July 2026, consolidated version published)` - 12 edges
6. `Wildfire prevention and safety reflexes in France` - 10 edges
7. `Wildfire-prevention ordinance in Montoro (Ordinanza n. 78/2026)` - 10 edges
8. `Météo des forêts (France)` - 8 edges
9. `2025 EU wildfire season` - 7 edges
10. `Fire Weather Index (FWI) System` - 7 edges

## Surprising Connections (you probably didn't know these)
- `Bollettino di previsione nazionale incendi boschivi (Italy)` --semantically_similar_to--> `Météo des forêts (France)`  [INFERRED] [semantically similar]
  bollettino-previsione-incendi-italia.md → meteo-des-forets-france.md
- `Wildfire prevention and safety reflexes in France` --semantically_similar_to--> `Wildfire prevention and safety reflexes in Italy`  [INFERRED] [semantically similar]
  wildfire-prevention-france.md → wildfire-prevention-safety-italy.md
- `France 2019: 15,000 ha burned; 80% of fires start under 50 m from dwellings; 90% of destroyed houses on uncleared land` --conceptually_related_to--> `Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access`  [INFERRED]
  wildfire-prevention-france.md → legal-brush-clearing-obligation-france.md
- `Montoro protection strips (20 m around settlements, 5 m around land)` --semantically_similar_to--> `Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access`  [INFERRED] [semantically similar]
  wildfire-prevention-ordinance-montoro.md → legal-brush-clearing-obligation-france.md
- `Pla Alfa five municipal danger levels (0 low to 4 extreme), updated at 00:00 and 9:30` --semantically_similar_to--> `Bouches-du-Rhône four daily fire-risk levels (faible/léger/modéré, sévère, très sévère, extrême)`  [INFERRED] [semantically similar]
  pla-alfa-catalonia.md → massif-access-regulation-bouches-du-rhone.md

## Hyperedges (group relationships)
- **Source contradictions recorded by ingest/lint**: 2025_eu_wildfire_season_scope_contradiction, 2025_eu_wildfire_season_august_share_contradiction, massif_access_regulation_bouches_du_rhone_order_number_contradiction, massif_access_regulation_bouches_du_rhone_fire_start_stats_contradiction, outdoor_fire_regulation_charente_maritime_repeal_date_contradiction, green_waste_burning_ban_france_penalty_contradiction, outdoor_fire_regulation_charente_maritime_gas_barbecue_contradiction, wildfire_prevention_france_carelessness_contradiction, legal_brush_clearing_obligation_france_mayor_vs_prefet_contradiction [EXTRACTED 1.00]
- **EU wildfire monitoring and response system**: effis, effis_jrc, effis_copernicus_emergency_management_service, eu_wildfire_risk_management_integrated_approach_2026, eu_wildfire_risk_management_resceu, eu_wildfire_risk_management_ucpm [INFERRED 0.85]
- **Daily fire-danger scales compared in the wiki**: fire_weather_index_six_danger_classes, meteo_des_forets_france_four_danger_levels, fire_danger_codes_flanders_four_colour_codes, pla_alfa_catalonia_five_levels, bollettino_previsione_incendi_italia_three_danger_levels, outdoor_fire_regulation_charente_maritime_six_vigilance_levels, massif_access_regulation_bouches_du_rhone_fire_risk_levels [INFERRED 0.75]

## Communities (8 total, 0 thin omitted)

### Community 0 - "Brush clearing, massif access and the wiki log"
Cohesion: 0.15
Nodes (24): Bouches-du-Rhône OLD prefectoral order of 15 October 2025 (replaces the order of 12 November 2014), Code forestier, DDTM des Bouches-du-Rhône (direction départementale des territoires et de la mer), Law n° 2023-580 of 10 July 2023 (fire-risk prevention, stronger sanctions), Bouches-du-Rhône clearing widths for linear infrastructure (20 m main roads and railways, 10 m communal roads, 5 to 10 m power lines), Contradiction: mayor (national rule) vs préfet (Bouches-du-Rhône) controls brush clearing on linear infrastructure, Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access, Office National des Forêts (ONF) (+16 more)

### Community 1 - "Danger scales: FWI, France, Flanders, Catalonia"
Cohesion: 0.15
Nodes (19): Belgian Wildfire Network, Climate change and wildfire risk in France, +4 °C France by 2100 scenario (fire risk nationwide, season 1 to 2 months longer in some regions), Fire-danger colour codes in Flanders (Belgium), Flemish four colour codes (green, yellow, orange, red), set per province, 1 March to 30 September, Royal Meteorological Institute of Belgium (KMI), Natuur en Bos (ANB), Fire Weather Index (FWI) System (+11 more)

### Community 2 - "EU 2025 season and monitoring"
Cohesion: 0.17
Nodes (17): 2025 EU wildfire season, Advance Report on Forest Fires in Europe, Middle East and North Africa 2025 (12 October 2026), 2 242 195 ha burnt in all EFFIS territories in 2025 (Ukraine almost 30%), August 2025 heatwave: 22 very large fires in Portugal and Spain (460 585 ha), Contradiction: August fires 43% vs nearly half of EU burnt area, 1 079 538 ha burnt in the EU in 2025 (7 783 fires, 25 of 27 Member States), Natura 2000 (39% of EU burnt area, 424 023 ha in 2025), Contradiction: scope of the 2.2 million ha figure (EU included or beyond the EU) (+9 more)

### Community 3 - "Waste burning and Charente-Maritime orders"
Cohesion: 0.23
Nodes (13): Ban on burning green waste in France, 750 EUR fine for burning green waste (also for selling an incinerator), Code de l'environnement (L541-21-1, R541-78), Contradiction: 750 EUR national fine vs contravention classes in Charente-Maritime, Ministerial order of 6 February 2024 (woods and forests exposed to fire risk), Arrêté préfectoral n° 24EB441 (repealed), Arrêté préfectoral n° 26EB142 (in force 1 May 2026), Arrêté n° 26EB443 of 24 June 2026 (excludes harvesting, haymaking, mowing, baling) (+5 more)

### Community 4 - "Italy: bulletin, Vesuvius, alert numbers"
Cohesion: 0.22
Nodes (10): Bollettino di previsione nazionale incendi boschivi (Italy), Dipartimento della Protezione Civile (Italy), Directive on active wildfire fighting of 1 July 2011, Bollettino three levels (low, medium, high), forecast up to 24 hours, 2017 wildfires in the Vesuvius National Park, 3194 ha damaged in July/August 2017 (about 80% of the park's woods; 374 ha high severity), Post-fire restoration plan (650 ha priority; two pilot projects under review on 80 ha, 1.2 M EUR, per the park's undated slides), French fire alert numbers (112, 18, 114); a car is not a safe shelter (+2 more)

### Community 5 - "Montoro ordinance and fireworks"
Cohesion: 0.24
Nodes (11): Festive fires and dérogations: request to the mayor 5 working days ahead, 9h-16h, piles at most 5 m wide and 2 m high; flying lanterns always banned, Fireworks forbidden in massifs; from SÉVÈRE only at sea or on the foreshore; all forbidden from TRÈS SÉVÈRE, Wildfire-prevention ordinance in Montoro (Ordinanza n. 78/2026), Montoro residue burning outside the maximum-danger period: 9:00-15:00, 50 m from woods, 100 m from dwellings, at most 5 piles, Decreto Dirigenziale n. 212 of 9 June 2026 (Regione Campania high-danger period, 15 June to 30 September 2026), Montoro penalties: administrative fine of 25 to 500 EUR; Codice Penale 423, 423-bis, 449, 650, Montoro fireworks and flying-lantern ban: not less than 1 km from woods and pastures, Legge n. 353/2000 (+3 more)

### Community 6 - "French prevention pages and human causes"
Cohesion: 0.36
Nodes (9): Legal obligation to clear brush (débroussaillement) in France, Access and works regulation in Bouches-du-Rhône forest massifs, Bouches-du-Rhône: 90% of fire starts of human origin, half due to carelessness, Outdoor fire use regulation in Charente-Maritime (arrêté n° 26EB142), DDTM de la Charente-Maritime (contact point of the prevention page), Wildfire prevention and safety reflexes in France, France 2019: 15,000 ha burned; 80% of fires start under 50 m from dwellings; 90% of destroyed houses on uncleared land, Contradiction: 9 in 10 fires mainly due to carelessness vs half due to carelessness (news item of 23 July 2026) (+1 more)

### Community 7 - "Daily risk levels and services in France"
Cohesion: 0.50
Nodes (5): Bouches-du-Rhône four daily fire-risk levels (faible/léger/modéré, sévère, très sévère, extrême), Direction générale de la sécurité civile et de la gestion des crises (DGSCGC), Météo-France, CODIS Charente-Maritime, Charente-Maritime six vigilance levels (FAIBLE to EXCEPTIONNEL), published from 18:00 the day before

## Knowledge Gaps
- **16 isolated node(s):** `Natura 2000 (39% of EU burnt area, 424 023 ha in 2025)`, `Expert Group on Forest Fires (43 countries)`, `European firefighting hub in Cyprus`, `Royal Meteorological Institute of Belgium (KMI)`, `+4 °C France by 2100 scenario (fire risk nationwide, season 1 to 2 months longer in some regions)` (+11 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 18 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Wiki update log` connect `Brush clearing, massif access and the wiki log` to `Danger scales: FWI, France, Flanders, Catalonia`, `EU 2025 season and monitoring`, `Waste burning and Charente-Maritime orders`, `Italy: bulletin, Vesuvius, alert numbers`, `Montoro ordinance and fireworks`, `French prevention pages and human causes`?**
  _High betweenness centrality (0.367) - this node is a cross-community bridge._
- **Are the 2 inferred relationships involving `Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access` (e.g. with `France 2019: 15,000 ha burned; 80% of fires start under 50 m from dwellings; 90% of destroyed houses on uncleared land` and `Montoro protection strips (20 m around settlements, 5 m around land)`) actually correct?**
  _`Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access` has 2 INFERRED edges - model-reasoned connections that need verification._
- **What connects `Natura 2000 (39% of EU burnt area, 424 023 ha in 2025)`, `Expert Group on Forest Fires (43 countries)`, `European firefighting hub in Cyprus` to the rest of the system?**
  _16 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Why does `Commission integrated approach to wildfire risk management (25 March 2026)` connect `EU 2025 season and monitoring` to `Brush clearing, massif access and the wiki log`?**
  _High betweenness centrality (0.157) - this node is a cross-community bridge._
- **Why does `European Forest Fire Information System (EFFIS)` connect `EU 2025 season and monitoring` to `Danger scales: FWI, France, Flanders, Catalonia`?**
  _High betweenness centrality (0.150) - this node is a cross-community bridge._
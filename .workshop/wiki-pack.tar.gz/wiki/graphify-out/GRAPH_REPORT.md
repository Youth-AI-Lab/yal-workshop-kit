# Graph Report - wiki  (2026-10-21)

## Corpus Check
- Corpus is ~16,359 words - fits in a single context window. You may not need a graph.

## Summary
- 82 nodes · 132 edges · 7 communities
- Extraction: 87% EXTRACTED · 13% INFERRED · 0% AMBIGUOUS · INFERRED: 17 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Italy: alerts, Vesuvius, Montoro
- EU 2025 season and monitoring
- Brush clearing law (France)
- Flanders codes and climate risk
- French fire rules and penalties
- Contradictions and wiki log
- Regional danger levels and services

## God Nodes (most connected - your core abstractions)
1. `Arrêté préfectoral n° 26EB142 (in force 1 May 2026)` - 12 edges
2. `Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access` - 11 edges
3. `European Forest Fire Information System (EFFIS)` - 9 edges
4. `Wiki update log` - 9 edges
5. `Wildfire prevention and safety reflexes in France` - 9 edges
6. `Prefectoral order of 22 April 2025 on massif access (consolidated 9 July 2026)` - 8 edges
7. `Wildfire-prevention ordinance in Montoro (Ordinanza n. 78/2026)` - 8 edges
8. `2025 EU wildfire season` - 7 edges
9. `Fire-danger colour codes in Flanders (Belgium)` - 7 edges
10. `Météo des forêts (France)` - 7 edges

## Surprising Connections (you probably didn't know these)
- `+4 °C France by 2100 scenario (fire risk nationwide, season 1-2 months longer)` --conceptually_related_to--> `2025 EU wildfire season`  [INFERRED]
  climate-change-wildfire-risk-france.md → 2025-eu-wildfire-season.md
- `Bollettino di previsione nazionale incendi boschivi (Italy)` --semantically_similar_to--> `Météo des forêts (France)`  [INFERRED] [semantically similar]
  bollettino-previsione-incendi-italia.md → meteo-des-forets-france.md
- `Montoro protection strips (20 m around settlements, 5 m around land)` --semantically_similar_to--> `Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access`  [INFERRED] [semantically similar]
  wildfire-prevention-ordinance-montoro.md → legal-brush-clearing-obligation-france.md
- `Wildfire-prevention ordinance in Montoro (Ordinanza n. 78/2026)` --semantically_similar_to--> `Arrêté préfectoral n° 26EB142 (in force 1 May 2026)`  [INFERRED] [semantically similar]
  wildfire-prevention-ordinance-montoro.md → outdoor-fire-regulation-charente-maritime.md
- `Wildfire prevention and safety reflexes in France` --semantically_similar_to--> `Wildfire prevention and safety reflexes in Italy`  [INFERRED] [semantically similar]
  wildfire-prevention-france.md → wildfire-prevention-safety-italy.md

## Hyperedges (group relationships)
- **EU wildfire monitoring and response system** — effis, effis_jrc, effis_copernicus_emergency_management_service, eu_wildfire_risk_management_integrated_approach_2026, eu_wildfire_risk_management_resceu, eu_wildfire_risk_management_ucpm [INFERRED 0.85]
- **Source contradictions recorded by ingest/lint** — 2025_eu_wildfire_season_scope_contradiction, 2025_eu_wildfire_season_august_share_contradiction, massif_access_regulation_bouches_du_rhone_order_number_contradiction, massif_access_regulation_bouches_du_rhone_fire_start_stats_contradiction, outdoor_fire_regulation_charente_maritime_repeal_date_contradiction, green_waste_burning_ban_france_penalty_contradiction [EXTRACTED 1.00]

## Communities (7 total, 0 thin omitted)

### Community 0 - "Italy: alerts, Vesuvius, Montoro"
Cohesion: 0.17
Nodes (14): Bollettino di previsione nazionale incendi boschivi (Italy), Dipartimento della Protezione Civile (Italy), Directive on active wildfire fighting of 1 July 2011, Bollettino three levels (low, medium, high), 2017 wildfires in the Vesuvius National Park, Post-fire restoration plan (650 ha priority, two pilot projects, 1.2 M EUR), French fire alert numbers (112, 18, 114), Wildfire-prevention ordinance in Montoro (Ordinanza n. 78/2026) (+6 more)

### Community 1 - "EU 2025 season and monitoring"
Cohesion: 0.21
Nodes (14): 2025 EU wildfire season, Advance Report on Forest Fires in Europe, Middle East and North Africa 2025, 1 079 538 ha burnt in the EU in 2025, Natura 2000 (39% of burnt area in 2025), Contradiction: scope of the 2.2 million ha figure (EU included or beyond the EU), European Forest Fire Information System (EFFIS), Copernicus Emergency Management Service, Expert Group on Forest Fires (43 countries) (+6 more)

### Community 2 - "Brush clearing law (France)"
Cohesion: 0.22
Nodes (12): Bouches-du-Rhône OLD prefectoral order of 15 October 2025, Code forestier, Law n° 2023-580 of 10 July 2023 (fire-risk prevention), Ministerial order of 6 February 2024 (woods and forests exposed to fire risk), Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access, Office National des Forêts (ONF), Prefectoral order of 22 April 2025 on massif access (consolidated 9 July 2026), Bouches-du-Rhône forest-fire protection plan (PDPFCI, 8 January 2024) (+4 more)

### Community 3 - "Flanders codes and climate risk"
Cohesion: 0.21
Nodes (12): Belgian Wildfire Network, Climate change and wildfire risk in France, +4 °C France by 2100 scenario (fire risk nationwide, season 1-2 months longer), Fire-danger colour codes in Flanders (Belgium), Flemish four colour codes (green, yellow, orange, red), Royal Meteorological Institute of Belgium (KMI), Natuur en Bos (ANB), Météo des forêts (France) (+4 more)

### Community 4 - "French fire rules and penalties"
Cohesion: 0.30
Nodes (12): Ban on burning green waste in France, 750 EUR fine for burning green waste, Code de l'environnement (L541-21-1, R541-78), Contradiction: 750 EUR national fine vs contravention classes in Charente-Maritime, Legal obligation to clear brush (débroussaillement) in France, Access and works regulation in Bouches-du-Rhône forest massifs, Outdoor fire use regulation in Charente-Maritime (arrêté n° 26EB142), Arrêté préfectoral n° 26EB142 (in force 1 May 2026) (+4 more)

### Community 5 - "Contradictions and wiki log"
Cohesion: 0.22
Nodes (9): August 2025 heatwave: 22 very large fires in Portugal and Spain, Contradiction: August fires 43% vs nearly half of EU burnt area, Wiki update log, Contradiction: ~250 fire starts / 1900 ha per year vs >228 / 1,930 ha (1975-2024), Contradiction: order number 13-2025-22-04-00011 vs 13-2025-04-22-00011, Arrêté préfectoral n° 24EB441 (repealed), Arrêté n° 26EB443 of 24 June 2026 (excludes harvesting, haymaking, mowing, baling), Contradiction: 24EB441 dated 27 June 2024 vs 'du 1er juillet 2024' (+1 more)

### Community 6 - "Regional danger levels and services"
Cohesion: 0.33
Nodes (7): Bouches-du-Rhône four daily fire-risk levels (faible/léger/modéré, sévère, très sévère, extrême), Direction générale de la sécurité civile et de la gestion des crises (DGSCGC), Météo-France, CODIS Charente-Maritime, Charente-Maritime six vigilance levels (FAIBLE to EXCEPTIONNEL), Pla Alfa five municipal danger levels (0 low to 4 extreme), Pla INFOCAT (Catalonia civil-protection plan)

## Knowledge Gaps
- **15 isolated node(s):** `Natura 2000 (39% of burnt area in 2025)`, `Directive on active wildfire fighting of 1 July 2011`, `Bollettino three levels (low, medium, high)`, `Joint Research Centre (JRC)`, `Expert Group on Forest Fires (43 countries)` (+10 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 16 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Météo des forêts (France)` connect `Flanders codes and climate risk` to `Italy: alerts, Vesuvius, Montoro`, `French fire rules and penalties`, `Regional danger levels and services`?**
  _High betweenness centrality (0.323) - this node is a cross-community bridge._
- **Are the 2 inferred relationships involving `Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access` (e.g. with `Fire spread and vertical/horizontal fuel discontinuities` and `Montoro protection strips (20 m around settlements, 5 m around land)`) actually correct?**
  _`Obligations légales de débroussaillement (OLD): 200 m zone, 50 m around buildings, 10 m along access` has 2 INFERRED edges - model-reasoned connections that need verification._
- **What connects `Natura 2000 (39% of burnt area in 2025)`, `Directive on active wildfire fighting of 1 July 2011`, `Bollettino three levels (low, medium, high)` to the rest of the system?**
  _15 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Why does `Wildfire prevention and safety reflexes in France` connect `French fire rules and penalties` to `Italy: alerts, Vesuvius, Montoro`, `Flanders codes and climate risk`?**
  _High betweenness centrality (0.250) - this node is a cross-community bridge._
- **Why does `Fire-danger colour codes in Flanders (Belgium)` connect `Flanders codes and climate risk` to `EU 2025 season and monitoring`?**
  _High betweenness centrality (0.241) - this node is a cross-community bridge._
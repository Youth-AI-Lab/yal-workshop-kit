---
type: Topic
title: "Belgian Wildfire Network"
description: "A network bringing together science, operational expertise and policy to prepare Belgium for nature fires across all its regions."
tags: [belgium, actor]
sources:
  - { id: anbcodes, resource: ../corpus/60-vlaanderen-brandgevaarcodes.html, title: "Brandpreventie in natuur- en bosgebieden op basis van kleurcodes" }
generated: { by: claude-sonnet-5, at: 2026-10-20T12:00:00Z }
---
# Belgian Wildfire Network

Natuur en Bos (ANB), the Flemish nature and forest agency, is one of the core partners of the
Belgian Wildfire Network.[^anbcodes] The network brings together science, operational expertise
and policy to better prepare Belgium for nature fires, across all its regions.[^anbcodes]

## See also
- [Fire-danger colour codes in Flanders (Belgium)](fire-danger-codes-flanders.md)

[^anbcodes]: Brandpreventie in natuur- en bosgebieden op basis van kleurcodes

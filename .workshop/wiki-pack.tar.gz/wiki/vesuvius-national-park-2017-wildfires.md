---
type: Topic
title: "2017 wildfires in the Vesuvius National Park"
description: "Extent and severity of the July–August 2017 fires in the Parco Nazionale del Vesuvio, their effect on future fire risk, and the post-fire restoration plan."
tags: [campania, italy, statistics, restoration]
sources:
  - { id: pnv-2017, resource: ../corpus/72-vesuvio-incendi-2017.docx, title: "PNV-29-gen-slides — incendi 2017 nel Parco Nazionale del Vesuvio" }
generated: { by: claude-sonnet-5, at: 2026-10-20T00:00:00Z }
---
# 2017 wildfires in the Vesuvius National Park

The sequence of fires that developed in July/August 2017 within the perimeter of the Parco
Nazionale del Vesuvio damaged an area of 3194 hectares, around 80% of the park's total wooded
area, broken down by severity class as: high severity 374 ha; medium-high 2147 ha; medium-low
466 ha; low 207 ha.[^pnv-2017]

The fire significantly altered the risk of forest fires for the following summer seasons. The
widespread mortality of conifer reforestation, the collapse of dead wood (necromass) on the
ground, the opening of canopies in broadleaf woods, and the growth of herbaceous and shrub
vegetation are expected to produce, over the following 10 years, a progressive increase in
small, medium and large fuel loads; absent appropriate management, this could increase the
risk of new fires able to spread over large areas.[^pnv-2017]

## Post-fire recovery planning

To identify the areas to target for post-fire recovery, four specific objectives were analysed:
hydrogeological risk, usability (fruibilità), naturalness, and agro-forestry production.[^pnv-2017]
Post-fire erosion processes can cause soil loss severe enough to compromise optimal vegetation
regrowth; the wooded areas most exposed to erosion are conifer stands with high and
medium-high fire severity.[^pnv-2017] Using a multicriteria approach across the usability,
naturalness and agro-forestry production objectives, 650 ha of area were identified as high
priority for intervention, of which 300 ha are suitable for primary intervention.[^pnv-2017]

The post-fire analysis concludes that intervention should prioritise conifer stands with high
and medium-high fire severity, through selective felling and the planting of native species
that are less susceptible to fire and better adapted to it.[^pnv-2017] In these areas,
naturalistic engineering works are planned to counter erosion processes and create conditions
for rapid vegetation establishment.[^pnv-2017]

Two pilot projects for post-fire forest restoration are being processed (in the approval
stage), covering interventions on about 80 hectares of pine forest across four municipalities
around Vesuvius — Terzigno, Boscotrecase, Trecase and Ottaviano — for a total cost of
1,200,000 euros.[^pnv-2017]

## See also
- [Wildfire-prevention ordinance in Montoro (Ordinanza n. 78/2026)](wildfire-prevention-ordinance-montoro.md)
- [Wildfire prevention and safety reflexes in Italy](wildfire-prevention-safety-italy.md)

[^pnv-2017]: PNV-29-gen-slides — incendi 2017 nel Parco Nazionale del Vesuvio

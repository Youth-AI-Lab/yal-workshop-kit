---
type: Topic
title: "Access and works regulation in Bouches-du-Rhône forest massifs"
description: "Bouches-du-Rhône's daily access restrictions to forest massifs and regulation of works liable to start fires, from 1 June to 30 September."
tags: [bouches-du-rhone, massif-access, regulation]
sources:
  - { id: bdr-acces-massifs, resource: ../corpus/40-bouches-du-rhone-acces-massifs.html, title: "Accès et travaux dans les massifs forestiers des Bouches-du-Rhône" }
  - { id: bdr-old-dossier-presse, resource: ../corpus/41-bouches-du-rhone-old-dossier-presse.pdf, title: "Les obligations légales de débroussaillement (O.L.D.) dans les Bouches-du-Rhône - dossier de presse" }
  - { id: bdr-arrete-consolide, resource: ../corpus/43-bouches-du-rhone-arrete-acces-consolide.pdf, title: "Arrêté préfectoral réglementant l'accès, la circulation, la présence des personnes et l'usage de matériels ou engins pouvant être à l'origine d'un départ de feu dans les espaces exposés aux risques d'incendies de forêt - version consolidée du 9 juillet 2026" }
generated: { by: claude_code/claude-opus-5-5, at: 2026-11-03T00:00:00Z }
---
# Access and works regulation in Bouches-du-Rhône forest massifs

Bouches-du-Rhône is one of the départements most exposed to forest-fire risk in metropolitan
France.[^bdr-acces-massifs] This danger is linked to climatic conditions (high heat, wind, plant
and soil dryness), making vegetation vulnerable to the smallest fire start: a simple cigarette
butt, a spark, a barbecue or carelessness can cause a disaster.[^bdr-acces-massifs] In the
département, forest covers a third of its surface, around 175,000 hectares.[^bdr-old-dossier-presse]
According to one source, about 250 fire starts per year occur, for an area burned of about
1900 ha/year, with close to 90% of fire starts of human origin;[^bdr-acces-massifs] according to
another, an annual average of more than 228 fire starts threatening the massifs is recorded over
the period 1975–2024, for an area burned by flames of 1,930 hectares.[^bdr-old-dossier-presse]

From 1 June to 30 September inclusive, access, presence and movement in forest massifs (and in works
liable to start fires) are subject to a prefectoral order of 22 April 2025.[^bdr-acces-massifs] Its
application can be extended beyond this period by prefectoral order in exceptional
circumstances.[^bdr-arrete-consolide] According to the HTML summary page, this order is numbered
13-2025-22-04-00011;[^bdr-acces-massifs] according to the consolidated order's own text, its number
is 13-2025-04-22-00011.[^bdr-arrete-consolide] The order covers forest massifs and the 200-metre
band bordering them, and rests on the French forest code (articles L.131-6, R.163-2, R.163-6), the
general code of territorial collectivities (articles L.2212-1 et seq.), the environment code
(article L.362-1), the law n°2023-580 of 10 July 2023 on strengthening fire prevention, and the
département's forest-fire protection plan (PDPFCI) approved by prefectoral order n°20240108/SAF/PF
of 8 January 2024.[^bdr-arrete-consolide] Each day, depending on the risk assessed by Météo-France,
works may be authorised under conditions, restricted, or forbidden in case of "très sévère" or
"extrême" risk.[^bdr-acces-massifs] These restrictions apply both to professionals on worksites and
to works carried out by individuals near forest massifs.[^bdr-acces-massifs] The order of 22 April
2025 was partially revised by an order of 9 July 2026, and a consolidated version of the order was
also published.[^bdr-acces-massifs]

## Fire-risk levels

Each day, the préfet determines a forest-fire risk level for the next day, for each forest massif,
based on forecasts from Météo-France's specialised unit; the assessment accounts for the risk of
ignition, the potential speed of fire spread, and the pressure on firefighting
capacity.[^bdr-arrete-consolide] Four increasing levels are set: "faible, léger ou modéré" (low,
slight or moderate), "sévère" (severe), "très sévère" (very severe), and "extrême"
(extreme).[^bdr-arrete-consolide]

## Daily access to massifs

Between 1 June and 30 September, accessibility to massifs is determined daily according to weather
and drought conditions, and is mapped and made public for each massif and for all communes
concerned, around 18:00 for the next day.[^bdr-acces-massifs] The interactive accessibility map is
available and updated from 1 June 2025.[^bdr-acces-massifs] The same information can also be found
on the MyProvence Balade website, on the "MesCalanques" smartphone app (for the Calanques massif
only), and via the access maps of neighbouring départements (Var, Vaucluse,
Gard).[^bdr-acces-massifs]

Access (including by sea), movement and presence in massifs are authorised at "faible, léger ou
modéré" risk and at "sévère" risk; forbidden at "très sévère" risk, except under a dérogation
granted within a ZAPEF (see below); and forbidden at "extrême" risk.[^bdr-arrete-consolide] At "très
sévère" and "extrême" risk, several categories are not subject to the ban: drivers crossing massifs
on paved public roads, with parking strictly limited to ZAPEF sites; people on a public-service
mission listed in an annex to the order, or holding an authorisation from the DDTM; owners or
tenants, and their ascendants or descendants, accessing their property; service providers or
contractors accessing a property under contract with its owner or tenant; people carrying out an
agricultural or pastoral activity whose presence is essential so as not to compromise production;
établissements recevant du public (ERP) located in forest massifs, whose legal brush-clearing
obligations are deemed to be carried out and compliant with the brush-clearing order in force in the
département; managers, employees and users of enclosed, staffed, paying commercial or
outdoor-leisure sites that comply with brush-clearing obligations; and landscaped cemeteries located
in forest massifs.[^bdr-arrete-consolide] Access to massifs during a risk period is at each person's
own responsibility, and professionals of outdoor activities are not authorised to operate in massifs
classified at "très sévère" or "extrême" risk.[^bdr-arrete-consolide]

Access restrictions are proportionate to the risk incurred, and in particular allow: everyone to
avoid exposure to toxic smoke and flames; fire and rescue services to concentrate their action
against the fire front; and individuals and businesses to avoid being held responsible for a fire
start linked to works.[^bdr-acces-massifs] 90% of fire starts are of human origin, half of which
are due to carelessness and dangerous behaviour, by both tourists and local
residents.[^bdr-acces-massifs] Basic safety reflexes therefore include bans on smoking, lighting a
campfire, or a barbecue, plus specific rules for works.[^bdr-acces-massifs]

## Zones d'accueil du public en forêt (ZAPEF)

A ZAPEF is a natural site within a forest massif that cumulatively: benefits from public management
(a dérogation request made by a local authority, which commits to carrying out the measures
prescribed in the authorisation); is particularly touristic or frequented; is secured against
forest-fire risk (at minimum: brush-clearing obligations carried out, accessibility for rescue
vehicles, and firefighting water points within 200 m under the département's DECI rules or the
instructing services' specific requirements); and is used collectively for leisure
purposes.[^bdr-arrete-consolide] The site's manager may request this specific regime to allow public
access; they remain responsible for the safety of the public received, and commit to fitting out,
monitoring, and facilitating fire management on the site.[^bdr-arrete-consolide] The dérogation
request must be filed every year by 28 February at the latest with the DDTM, by email to
ddtm-foret@bouches-du-rhone.gouv.fr, and is submitted for an opinion to the departmental
sub-commission for fire safety before the préfet's decision.[^bdr-arrete-consolide] ZAPEF status is
granted on a precarious and revocable basis; the list of ZAPEF sites is published on the État's
departmental website.[^bdr-arrete-consolide]

## Works liable to start fires

The use of equipment or machinery that can start a fire by heating or by producing sparks, in areas
exposed to forest-fire risk (defined as **forest massifs plus a 200-metre zone all around them**)
is regulated proportionately to the day's risk level.[^bdr-acces-massifs] This applies to works
carried out by both individuals and businesses, but not to works carried out as part of active
firefighting against an ongoing fire.[^bdr-arrete-consolide] A dedicated map of the daily fire-risk
level for works carried out by individuals or professionals is available and updated from 1 June
2025.[^bdr-acces-massifs]

Such works are authorised all day at "faible, léger ou modéré" risk, provided permanent safety is
ensured by the prevention and extinguishing equipment set out in an annex to the order; authorised
from 5h to 13h at "sévère" risk under the same condition, and forbidden (except dérogation) from 0h
to 5h and from 13h to 24h; and forbidden all day at "très sévère" and "extrême" risk, except
dérogation.[^bdr-arrete-consolide] Required equipment includes, for individuals, a hose connected to
a water supply, long enough to reach any point of the worksite; and for professionals, depending on
the equipment used: for tractors with crushers, flail mowers, harvesters or thermal/electric
weeders, and for grinders, concrete saws, disc cutters or welding sets, one 9 kg powder
extinguisher, one 9-litre water extinguisher and an extinguishing device delivering at least 40
litres of water per minute, made of a motor pump unit with a minimum 450-litre water reserve, a
water lance and a hose long enough to reach any point of the worksite, and in addition screens and
anti-projection plates for metal works and fireproof tarps for welding; for site machinery without a
crusher and site or transport vehicles, at minimum one 9 kg powder extinguisher and one 9-litre
water extinguisher; for a generator, the same, placed on a cleared area free of vegetation; and for
branch shredders, cement mixers, motor welders, thermal engines, chainsaws, pruners or brush
cutters, one 9 kg powder extinguisher and one 9-litre water extinguisher close at hand (15 m at
most) for every person working on the site, and on every vehicle present on the
site.[^bdr-arrete-consolide]

Works can cause fires either by producing sparks (metalworking, striking against stones, etc.) or
by heating (thermal engines, etc.).[^bdr-acces-massifs] A fire start becomes possible when
vegetation is dried out, temperature is high, and wind blows strongly, favouring spread; in these
conditions the smallest spark suffices to start a fire, which can spread very rapidly and escape
all control, with potentially dramatic consequences for people, property and natural
environments.[^bdr-acces-massifs]

Rules to be strictly respected: keep to the authorised hours; do not carry out works during a "très
sévère" or "extrême" risk period; put in place prevention, monitoring and extinguishing equipment;
and stay informed of the daily risk level, updated at 18:00 for the next day.[^bdr-acces-massifs]

Dérogations to these restrictions, from "sévère" risk upward, apply to three categories of
operations.[^bdr-arrete-consolide] Works required by a non-postponable public-safety imperative, and
non-postponable agricultural works, are authorised under safety conditions (permanent
prevention/extinguishing equipment and an on-site means of communication for alerting the security
services and the rescue services), with the worksite's commune, the DDTM and the competent rescue
service informed beforehand by the works' initiator.[^bdr-arrete-consolide] Non-postponable works of
general interest or public utility are authorised by an individual préfectoral decision, provided
that safety is ensured at all times by at least the prevention and extinguishing equipment of the
annex (measures defined with the rescue services according to the works) and that a means of
communication for alerting the security services and the rescue services is available on the
worksite itself, after a request filed with the DDTM at least two months in advance via
démarches-simplifiées ("travaux_ete_13"), valid at most for the period from 1 June to 30 September
of the current year, with the DDTM informing the competent rescue services and the requester
informing the commune before the worksite starts.[^bdr-arrete-consolide] Fire-prevention works
carried out by APFM auxiliaries (auxiliaires de protection de la forêt méditerranéenne),
forestiers-sapeurs, or agents of the départemental domains are authorised under the same safety
conditions.[^bdr-arrete-consolide]

## Public events and professional filming

During June, July, August and September, organisers of public events or professional audiovisual
filming planned in the forest massifs of Bouches-du-Rhône must make a prior declaration to the
mayor, the DDTM, and the territorially competent fire and rescue service, at least two months
before the planned date.[^bdr-acces-massifs] The declaration file, filed via démarches-simplifiées
("manif-tournage-ete-foret-13"), includes a site plan, a traffic plan for accessing and evacuating
the site (including rescue access and vehicle parking areas), the measures the organiser commits to
for the event's or filming's safety in case of a forest fire, and the measures to prevent a fire
start caused by the event's or filming's presence and activity.[^bdr-arrete-consolide] The préfet
can decide to regulate or ban a declared public event or filming if the risk level requires it;
without this declaration, the public event or professional filming is forbidden.[^bdr-acces-massifs]

## Sanctions and legal recourse

Breaches of the order are liable to the penalties set out in article R.163-2 of the French forest
code.[^bdr-arrete-consolide] The order can be challenged by a recours gracieux within two months of
its notification, or by a recours contentieux before the tribunal administratif de Marseille within
two months of its notification (or of the explicit or implicit response to a recours gracieux),
including via the Télérecours citoyens online application.[^bdr-arrete-consolide]

## Orders in force

Prefectoral order n° 13-2025-22-04-00011 of 22 April 2025 regulates access to, movement in, and
presence in the forest massifs of Bouches-du-Rhône for the period from 1 June to 30
September;[^bdr-acces-massifs] the consolidated order's own text gives this same order the number
13-2025-04-22-00011.[^bdr-arrete-consolide] It was partially revised by an order of 9 July 2026
(numbered AP-2026-13-2026-07-09-00020 according to the HTML summary page[^bdr-acces-massifs]), and a
consolidated version of the order was also published.[^bdr-acces-massifs] This consolidated version
abrogates the earlier prefectoral order n°13-2018-05-28-005 of 28 May 2018 and the order of 1
October 2021 that had amended it.[^bdr-arrete-consolide] The order is notified to the mayors of all
communes of the département, displayed in town halls for two months, and published in the recueil
des actes administratifs.[^bdr-arrete-consolide]

## See also
- [Wildfire prevention and safety reflexes in France](wildfire-prevention-france.md)
- [Outdoor fire use regulation in Charente-Maritime (arrêté n° 26EB142)](outdoor-fire-regulation-charente-maritime.md)
- [Legal obligation to clear brush (débroussaillement) in France](legal-brush-clearing-obligation-france.md)

[^bdr-acces-massifs]: Accès et travaux dans les massifs forestiers des Bouches-du-Rhône
[^bdr-old-dossier-presse]: Les obligations légales de débroussaillement (O.L.D.) dans les Bouches-du-Rhône - dossier de presse
[^bdr-arrete-consolide]: Arrêté préfectoral réglementant l'accès, la circulation, la présence des personnes et l'usage de matériels ou engins pouvant être à l'origine d'un départ de feu dans les espaces exposés aux risques d'incendies de forêt - version consolidée du 9 juillet 2026

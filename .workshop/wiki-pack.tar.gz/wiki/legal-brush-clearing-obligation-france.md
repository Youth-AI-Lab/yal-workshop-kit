---
type: Topic
title: "Legal obligation to clear brush (débroussaillement) in France"
description: "Who must clear brush around buildings in France, the required depths, timing, exceptions, and the penalties for non-compliance."
tags: [france, brush-clearing]
sources:
  - { id: debroussaillement-sp, resource: ../corpus/22-service-public-debroussaillement.html, title: "Dans quel cas le débroussaillement est-il obligatoire ?" }
  - { id: cm-prevention-page, resource: ../corpus/32-charente-maritime-prevention-page.html, title: "Prévention des incendies de forêt, d'espaces naturels et agricoles" }
  - { id: bdr-old-dossier-presse, resource: ../corpus/41-bouches-du-rhone-old-dossier-presse.pdf, title: "Les obligations légales de débroussaillement (O.L.D.) dans les Bouches-du-Rhône — dossier de presse" }
  - { id: bdr-old-arrete-news, resource: ../corpus/42-bouches-du-rhone-old-arrete-2025.html, title: "Les OLD : nouvel arrêté préfectoral du 15 octobre 2025" }
generated: { by: claude-sonnet-5, at: 2026-10-20T13:00:00Z }
---
# Legal obligation to clear brush (débroussaillement) in France

Débroussaillement consists in reducing vegetation of any kind (grass, branches, leaves...) to
reduce the intensity of fires and slow their spread; it can involve pruning trees or shrubs, or
removing cutting residue.[^debroussaillement-sp] The precise conditions of implementation are
adapted to local conditions of the département and are set by prefectoral decree.[^debroussaillement-sp]

## Who is subject to the obligation

The legal obligation of brush clearing applies to land located **less than 200 metres from
forest areas, moorlands, maquis or garrigues classified as being at risk of fire**.[^debroussaillement-sp]
If a plot is not subject to the obligation, brush clearing is not mandatory but is still
**recommended** if the dwelling is close to a wooded area.[^debroussaillement-sp]

As **owner**, a person is responsible for brush clearing around their construction.[^debroussaillement-sp]
A **tenant** may carry it out if the lease specifies so, but this does not remove the owner's
criminal liability.[^debroussaillement-sp]

## Required depths

- Around the dwelling and other installations: a minimum depth of **50 metres** from the
  construction, which is not necessarily limited to the boundaries of the owner's own
  plot — brush-clearing work may need to be carried out on a neighbouring plot.[^debroussaillement-sp]
- Along access routes to the land (road, path, private track): a maximum depth of **10 metres**
  on each side of the route.[^debroussaillement-sp]
- In urban zones delimited by a local urban plan (PLU): the obligation additionally covers the
  **whole of the owner's plot**.[^debroussaillement-sp]

Particular rules can apply to land near linear infrastructure (power lines) and to land forming
part of a concerted development zone (ZAC), an urban land association, a housing estate, or a
campsite.[^debroussaillement-sp]

## Neighbouring land

If brush-clearing work must be carried out on a neighbour's plot, the owner must inform the
neighbour of the obligation, preferably by a letter with acknowledgement of receipt specifying
the nature of the work.[^debroussaillement-sp] The neighbour may choose to do the clearing
themselves; if they refuse access or do not reply within one month of the notification, the
responsibility for the clearing then falls to them, and the mayor must be informed.[^debroussaillement-sp]

## Timing

- Vegetation-reduction work (which can require cutting trees or shrubs) is recommended during
  **autumn and winter**.[^debroussaillement-sp]
- Maintenance of already-cleared zones (keeping low vegetation density, removing cuttings and
  flammable material near the dwelling) can be carried out in **spring**.[^debroussaillement-sp]
- Clearing during **drought** carries a fire risk, and clearing during the nesting period must
  avoid destroying species.[^debroussaillement-sp]

## Using a professional

An owner may hire a professional under contract to clear the land and keep it cleared, and may
be eligible, under certain conditions, for a **tax credit** for employing someone to do the
work.[^debroussaillement-sp]

## Disclosure on sale or lease (since 1 January 2025)

Since 1 January 2025, sellers and landlords of property located in a zone subject to the legal
brush-clearing obligation must inform the buyer or tenant, from the property listing onward, and
this information must be included in the risk disclosure statement ("état des risques").[^debroussaillement-sp]
In case of sale, the seller must certify on their honour that the brush-clearing obligations have
been respected; this certification must be annexed to the sale agreement and the deed of
sale.[^debroussaillement-sp]

## Sanctions for non-compliance

- **Criminal sanctions**: ranging from a fine of **1,500 €** up to an offence punishable by
  **50 €/m²** not cleared.[^debroussaillement-sp]
- **Administrative sanctions**: the mayor can issue a formal notice to clear ("mise en demeure"),
  which can carry a daily penalty ("astreinte") of up to **100 € maximum per day** of delay; the
  mayor can also have the clearing work carried out at the owner's expense, and an administrative
  fine of up to **50 € per m²** not cleared can be imposed.[^debroussaillement-sp]
- **Insurance**: the insurance deductible can be increased, up to a maximum of **5,000 €**.[^debroussaillement-sp]

## Enforcement

The mayor is responsible for monitoring compliance with the legal brush-clearing obligations
around constructions and equipment, and can carry out checks directly or delegate this to sworn
personnel (notably agents of the Office National des Forêts, ONF).[^debroussaillement-sp] If the
mayor fails to act, the préfet can substitute for them.[^debroussaillement-sp] The mayor is also
responsible for compliance concerning linear infrastructure such as roads and railways.[^debroussaillement-sp]

## Legal basis

The obligation is set out in the Code forestier: definition and prefectoral decision (articles
L131-10 to L131-16), territories concerned (articles L132-1 to L132-3 and L133-1), perimeter of
clearing (articles L134-5 to L134-18), authorisation to enter neighbouring land (article R131-14),
formal notice to clear (articles R134-4 to R134-6), and administrative fine (articles L135-1 to
L135-2 and R163-3).[^debroussaillement-sp] The legal obligation to clear brush (obligations
légales de débroussaillement, OLD) was reinforced by law n° 2023-580 of 10 July 2023, which
constitutes an essential measure of forest-fire prevention policy.[^cm-prevention-page] The OLD
applies inside, or at less than 200 metres from, wooded massifs classified as being at risk of
fire in accordance with the ministerial order of 6 February 2024 (as amended), which classifies
the woods and forests exposed to fire risk.[^cm-prevention-page] The Géoportail website provides a
simplified map of the areas subject to the OLD, at
https://www.geoportail.gouv.fr/donnees/debroussaillement.[^cm-prevention-page] In Charente-Maritime,
72 communes are concerned by the OLD.[^cm-prevention-page]

## Bouches-du-Rhône

Given climate warming and the Mediterranean type of vegetation, the forest massifs of
Bouches-du-Rhône are particularly vulnerable to fire risk, as was experienced at the start of
summer 2025.[^bdr-old-arrete-news] The law relating to the development of a national and
territorial strategy to strengthen prevention, protection, and the fight against the
intensification and extension of fire risk was promulgated on 10 July 2023 and published in the
Journal officiel on 11 July 2023.[^bdr-old-arrete-news] As a result, the prefectoral order on the
legal brush-clearing obligations (O.L.D.), which dated from 12 November 2014, had to be
revised.[^bdr-old-arrete-news] The new order, signed on 15 October 2025, reaffirms the importance
of forest-fire prevention through the fulfilment of the legal brush-clearing obligations, which
must be respected permanently.[^bdr-old-arrete-news] The O.L.D. are an integral part of the
national strategy against forest fires and significantly reduce the impact of fires, by fighting
forest fires and protecting threatened homes.[^bdr-old-arrete-news] The law of 10 July 2023 also
strengthened the criminal and administrative sanctions for non-compliance with the legal
brush-clearing obligations; State services will support local authorities in controlling the OLD
among private individuals, and will also work to strengthen controls of compliance with the OLD
on linear infrastructure, which is the origin of many fire starts.[^bdr-old-arrete-news]

A new prefectoral order on the modalities of implementing the legal brush-clearing obligations
and of maintaining cleared land in Bouches-du-Rhône was signed on 15 October 2025, after
extensive consultation, since January 2024, with fire and rescue services, State services, the
Office national des forêts (ONF), local authorities, environmental associations and linear-network
managers.[^bdr-old-dossier-presse] It reaffirms the importance of fire-prevention brush clearing
while integrating measures favourable to biodiversity and to environmental and landscape
concerns:[^bdr-old-dossier-presse]

- protection of sensitive zones: no brush clearing in riverside woodlands (ripisylves) and
  riverbank stands;[^bdr-old-dossier-presse]
- ecological derogations allowing the retention of remarkable trees, groups of trees, patches of
  vegetation, and standing dead trees;[^bdr-old-dossier-presse]
- progressive clearing carried out from buildings toward natural areas, to let wildlife flee
  toward refuge zones;[^bdr-old-dossier-presse]
- a calendar restriction on carrying out the work, depending on the type of work and the
  equipment used.[^bdr-old-dossier-presse]

In Bouches-du-Rhône, the obligation applies to land less than 200 metres from woods and forests
("espaces exposés"), with clearing required over a depth of 50 metres around dwellings and 10
metres on each side of access routes (road, path, private track).[^bdr-old-dossier-presse]

### Clearing widths for managers of linear infrastructure

| Infrastructure | Clearing width |
| --- | --- |
| Motorways, national roads, departmental roads, railways | 20 m[^bdr-old-dossier-presse] |
| Communal roads | 10 m[^bdr-old-dossier-presse] |
| Power lines | 5 to 10 m depending on the type of line[^bdr-old-dossier-presse] |

### Actors

- **Owner**: responsible for brush clearing around each construction.[^bdr-old-dossier-presse]
- **Mayor**: controls compliance by residents (the municipal police can record offences), is, like
  any owner, responsible for clearing around communal buildings, and is responsible, as manager of
  roads open to public traffic, for clearing along communal roads.[^bdr-old-dossier-presse]
- **Préfet**: specifies the regulation applicable to the département's specifics; controls
  clearing of communal properties, linear infrastructure (power-transport networks, railways) and
  roads open to public traffic; substitutes for the mayor if the mayor fails to exercise police
  powers.[^bdr-old-dossier-presse]
- **DDTM** (direction départementale des territoires et de la mer): technical support to the
  préfet, and accompanies mayors in exercising their police powers (training municipal police,
  taking part in public meetings).[^bdr-old-dossier-presse]
- **ONF**: manager of public forests by right, also empowered to record forestry offences
  nationwide; acts at the préfet's request to implement the OLD control plan.[^bdr-old-dossier-presse]
- **CCFF/RCSC** (comité communal feux de forêts / réserve communale de sécurité civile): chaired
  by the mayor, can mobilise volunteers to deliver personalised information to
  owners.[^bdr-old-dossier-presse]
- **Network managers** (power-transport networks, railways, roads open to public traffic):
  responsible for brush clearing along their network.[^bdr-old-dossier-presse]
- **Firefighters**: raise awareness of the need for brush clearing, and are the main beneficiaries,
  since it lets them fight fires more effectively and safely.[^bdr-old-dossier-presse]
- **COFOR** (association départementale des communes forestières): organises training for elected
  officials.[^bdr-old-dossier-presse]

### Control and sanctions

The mayor is responsible in the first instance for controlling compliance with brush-clearing
obligations (except for linear networks and communal properties); State services support communes
and carry out joint, systematic control operations on targeted areas (public land, private land,
linear networks) under a multi-year programme.[^bdr-old-dossier-presse] Sanctions (a fine,
possibly combined with non-compliance with an administrative formal notice) are applied to those
who do not comply.[^bdr-old-dossier-presse]

Non-compliance with the OLD exposes the owner to a 5th-class contravention — a criminal fine of
up to **50 €/m²** not cleared, i.e. a potential fine of up to **392,500 €** — and to administrative
sanctions (formal notice to carry out the work, work carried out by the administration in the
owner's place, administrative fine of up to **50 €/m²** not cleared, i.e. a potential fine of up
to **392,500 €**).[^bdr-old-dossier-presse]

### How a forest fire spreads

A forest fire starts at ground level: fine fuel elements (grass, brushwood, small branches,
needles) catch fire and spread it to the tree crowns, where it becomes difficult to control
because it spreads rapidly from crown to crown; with a large fuel mass, the resulting flame front
is powerful, difficult to master, and can cause major damage.[^bdr-old-dossier-presse] Creating
vertical discontinuities (pruning, removal of brushwood and shrubs) slows the fire's progression
and reduces its intensity, while creating horizontal discontinuities (removal of trees and shrubs)
limits its advance; together these discontinuities favour keeping the fire at ground level (or
bringing it back down), greatly reduce its intensity, protect people and property, and let ground
crews attack the fire in relative safety and with better effectiveness.[^bdr-old-dossier-presse]

A leaflet produced by the Bouches-du-Rhône DDTM illustrates and summarises the prescriptions of the
prefectoral order and good practices, for the general public.[^bdr-old-dossier-presse]

## See also
- [Wildfire prevention and safety reflexes in France](wildfire-prevention-france.md)
- [Outdoor fire use regulation in Charente-Maritime (arrêté n° 26EB142)](outdoor-fire-regulation-charente-maritime.md)
- [Access and works regulation in Bouches-du-Rhône forest massifs](massif-access-regulation-bouches-du-rhone.md)

[^debroussaillement-sp]: Dans quel cas le débroussaillement est-il obligatoire ?
[^cm-prevention-page]: Prévention des incendies de forêt, d'espaces naturels et agricoles
[^bdr-old-dossier-presse]: Les obligations légales de débroussaillement (O.L.D.) dans les Bouches-du-Rhône — dossier de presse
[^bdr-old-arrete-news]: Les OLD : nouvel arrêté préfectoral du 15 octobre 2025

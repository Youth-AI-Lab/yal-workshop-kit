---
type: Topic
title: "Météo des forêts (France)"
description: "Météo-France's daily forecast of forest-fire danger levels by département, and what it does and does not tell the public."
tags: [france, fire-danger-index, what-to-do]
sources:
  - { id: meteoforets, resource: ../corpus/20-meteo-france-meteo-des-forets.html, title: "Météo des forêts" }
generated: { by: claude-sonnet-5, at: 2026-10-20T11:00:00Z }
---
# Météo des forêts (France)

Weather conditions strongly influence the start and spread of fires.[^meteoforets] To prevent
fires and let everyone adapt their behaviour to the foreseeable danger, Météo-France's "Météo
des forêts" indicates a forest-fire danger level established from weather forecasts and the
dryness state of vegetation.[^meteoforets] Météo-France has distributed it daily since
2023.[^meteoforets]

This information is delivered at the scale of the département, for the next day and the day
after, with 4 levels of danger representation: low, moderate, high, very high.[^meteoforets]

Météo des forêts does not report on fires that are ongoing or expected to start.[^meteoforets] A
low danger level does not mean there is no risk of fire in the département.[^meteoforets]

Depending on local situations, mairies and préfectures may restrict access to fire-exposed areas
and related activities; people should check their préfecture's website.[^meteoforets]

As of this document's retrieval (19 October 2026), the fire season was over in metropolitan
France, with the next Météo des forêts season starting in June 2027.[^meteoforets]

## The 4 danger levels

- **Very high danger (red)**: weather conditions make the risk of fire start and spread very
  high compared to summer norms.[^meteoforets]
- **High danger (orange)**: weather conditions significantly worsen the risk of fire start and
  spread compared to summer norms; the fire risk can be locally very high.[^meteoforets]
- **Moderate danger (yellow)**: weather conditions do not significantly worsen the risk of fire
  start and spread compared to summer norms; the fire risk can be locally high.[^meteoforets]
- **Low danger (green)**: forecast weather conditions and recent rainfall reduce the risk of
  fire start and spread.[^meteoforets]

## Météo-France's operational role

As part of its mission to protect people and property, Météo-France provides operational
support to firefighting actors and to the Direction générale de la sécurité civile et de la
gestion des crises (DGSCGC), which coordinates the national response.[^meteoforets]

## See also
- [Fire Weather Index (FWI) System](fire-weather-index.md)
- [Wildfire prevention and safety reflexes in France](wildfire-prevention-france.md)
- [Climate change and wildfire risk in France](climate-change-wildfire-risk-france.md)

[^meteoforets]: Météo des forêts

---
type: Topic
title: "Climate change and wildfire risk in France"
description: "Projected impact of climate change on forest-fire risk and the fire season in France."
tags: [france, climate-change, wildfires]
sources:
  - { id: meteoforets, resource: ../corpus/20-meteo-france-meteo-des-forets.html, title: "Météo des forêts" }
generated: { by: claude-sonnet-5, at: 2026-10-20T11:00:00Z }
---
# Climate change and wildfire risk in France

In a France that reaches +4 °C by 2100, fire risk would spread across the whole country, with a
sharp worsening in the Mediterranean region.[^meteoforets] The fire season could last 1 to 2
additional months in some regions.[^meteoforets]

## See also
- [Météo des forêts (France)](meteo-des-forets-france.md)

[^meteoforets]: Météo des forêts

---
type: Topic
title: "Outdoor fire use regulation in Charente-Maritime (arrêté n° 26EB142)"
description: "The Charente-Maritime prefectoral order governing outdoor fire use, leisure fires, fireworks, waste burning and vigilance levels, in force from 1 May 2026."
tags: [charente-maritime, regulation, prevention]
sources:
  - { id: arrete-26eb142, resource: ../corpus/30-charente-maritime-arrete-26EB142.pdf, title: "Arrêté préfectoral n° 26EB142 réglementant l'usage du feu à l'air libre" }
  - { id: cm-prevention-page, resource: ../corpus/32-charente-maritime-prevention-page.html, title: "Prévention des incendies de forêt, d'espaces naturels et agricoles" }
  - { id: arrete-24eb441, resource: ../corpus/33-charente-maritime-arrete-24EB441-repealed.pdf, title: "Arrêté préfectoral n° 24EB441 du 27 juin 2024 réglementant l'usage du feu" }
generated: { by: claude-sonnet-5, at: 2026-10-20T12:30:00Z }
---
# Outdoor fire use regulation in Charente-Maritime (arrêté n° 26EB142)

*This page is based on an OCR'd scan of the order; some figures or article numbers may be
imprecisely transcribed from the original.*

Prefectoral order n° 26EB142 regulates the outdoor use of fire across the whole département of
Charente-Maritime, to prevent forest and natural-area fires, facilitate firefighting and limit
their consequences.[^arrete-26eb142] It covers outdoor fire use in general: open-air hearths,
leisure fires, fireworks and pyrotechnic shows, and open-air burning (green waste, crop residue,
forestry waste, écobuage, controlled burning), including any combustion with or without visible
flame.[^arrete-26eb142] Electric and gas barbecues, planchas and electric stoves are not covered
by the order, though their user remains responsible for their stability and
supervision.[^arrete-26eb142] The order entered into force on 1 May 2026, repealing the previous
order n° 24EB441 of 1 July 2024.[^arrete-26eb142]

## Vigilance levels and zoning

The order's prevention measures are based on a daily vigilance level, which determines the
applicable restrictions: as the level rises, restrictions increase and can include banning the
use of fire or limiting certain work.[^arrete-26eb142] The information is based on Météo-France
forecasts and on analysis by the CODIS (Centre Opérationnel Départemental d'Incendie et de
Secours) of Charente-Maritime.[^arrete-26eb142] There are six increasing vigilance levels: FAIBLE
(blue), LÉGER (green), MODÉRÉ (yellow), SÉVÈRE (orange), TRÈS SÉVÈRE (red) and EXCEPTIONNEL
(black).[^arrete-26eb142] The vigilance level for day J is published from 18:00 on day
J-1.[^arrete-26eb142] If no vigilance-level data is available, only the general provisions of the
regulation in force apply.[^arrete-26eb142]

The vigilance level is assessed by four geographic sectors: Secteur 1 (1701), Secteur 2 (1702),
Secteur 3 (1703) and Secteur 4 (1704), each covering a listed set of communes (Annexe 2 of the
order).[^arrete-26eb142] Before lighting any fire, it is mandatory to identify the geographic zone
and its associated vigilance level.[^arrete-26eb142] This 4-sector division is the result of a
2026 update that created a 4th geographic sector by splitting the former sector 3, alongside a
new consultation platform (Valabre) for the vigilance-level map, published at
https://www.risque-prevention-incendie.fr/17, which also improved public information by
communicating the next day's vigilance level from 18:00.[^cm-prevention-page]

## Amendment of 24 June 2026 (arrêté n° 26EB443)

Prefectoral order n° 26EB443 of 24 June 2026 amends order n° 26EB142 by clarifying the scope of
the restrictions and bans applicable to agricultural work liable to start a fire: it **excludes
field-crop harvesting, haymaking, mowing and baling** ("exclut les récoltes de grande culture, de
fenaison, fauche et pressage") from those restrictions and bans.[^cm-prevention-page]

## Risk massifs and other wooded massifs

The order defines "massifs à risque" (risk massifs) as wooded massifs of more than 1 ha (woods,
moorlands, forest plantations, reforestations, garrigues, and land subject to a legal or
contractual afforestation obligation) located in the communes listed by the ministerial order of
6 February 2024, including the roads crossing them and all areas within a 200-metre perimeter
around them.[^arrete-26eb142] 72 communes across five massifs are listed as risk massifs: Île de
Ré (9 communes), Île d'Oléron (8 communes), Presqu'Île d'Arvert (9 communes), Forêt de la Lande
(17 communes) and Double Saintongeaise (29 communes).[^arrete-26eb142]

"Autres massifs" (other massifs) are wooded massifs of at least 0.5 ha anywhere in the
département, including the roads crossing them and all areas within a 200-metre perimeter around
them.[^arrete-26eb142]

## General ban in the massifs

Whatever the vigilance level, it is forbidden in all massifs to transport or throw ignited objects
(matches or other incandescent material), and to smoke.[^arrete-26eb142] It is forbidden for
anyone other than the landowner, or occupants authorised by the landowner, to carry or light fire
in any massif without authorisation; these bans also apply to users of public roads crossing these
lands.[^arrete-26eb142]

## Leisure fires

Landowners and their beneficiaries are allowed to hold leisure fires, subject to any local
restrictions (municipal orders, campsite/subdivision rules, co-ownership rules, etc.).[^arrete-26eb142]
Leisure fires include festive fires (feux de veillée, feux de la Saint-Jean, campfires, bonfires)
and cooking fires (méchouis, grilling, barbecues, braziers, stoves, éclades).[^arrete-26eb142]

- Festive fires are banned in risk massifs, and banned in other massifs from vigilance level
  SÉVÈRE (orange).[^arrete-26eb142] Releasing flying lanterns ("lanternes célestes / chinoises /
  thaïlandaises") is strictly forbidden across the whole département regardless of the vigilance
  level.[^arrete-26eb142]
- From vigilance level SÉVÈRE (orange), mobile gas, petrol/alcohol or wood stoves and planchas are
  forbidden in massifs, and ground cooking fires (méchouis, éclades) are forbidden in
  massifs.[^arrete-26eb142] Barbecues and stoves (charcoal, wood or gas/petrol/alcohol) remain
  allowed in massifs only on non-combustible areas meeting these conditions: each hearth
  surrounded by a 3-metre-radius non-combustible zone (bare ground, concrete or gravel);
  spark-arrester equipment; a water point with a hose able to reach the hearth and a 6-litre
  water-spray extinguisher nearby; constant supervision by users who must have a means of alert
  (mobile phone), with a notice of this obligation displayed by campsite/caravan-site operators; no
  tree overhanging the hearth and no branch within a 3-metre radius; brush clearing compliant with
  the Obligations Légales de Débroussaillement in risk massifs, or carried out within a 20-metre
  radius of the hearth in other massifs; and no fuel stock within 8 metres of a
  hearth.[^arrete-26eb142] From vigilance level TRÈS SÉVÈRE (red), these barbecues and stoves
  (charcoal, wood or petrol) are forbidden in massifs.[^arrete-26eb142]

## Fireworks and pyrotechnic shows

Pyrotechnic shows and fireworks are forbidden in the massifs, and their safety perimeter must
always be located outside any massif.[^arrete-26eb142] From vigilance level SÉVÈRE (orange),
fireworks and pyrotechnic shows are forbidden except those fired at sea or from the foreshore of
coastal beaches and the Gironde estuary, in which case the safety perimeter must not interfere
with the massifs and a 200-metre buffer zone must be kept between the perimeter and the
massifs.[^arrete-26eb142] From vigilance level TRÈS SÉVÈRE (red), all pyrotechnic shows and
fireworks are strictly forbidden.[^arrete-26eb142]

## Spark- or heat-generating equipment

Work liable to start a fire by heating or producing sparks (hot-point work, thermal weeding,
agricultural work, earthworks such as trenching, forestry work, cutting, welding, abrasion,
grinding/cutting discs) is, in all massifs: forbidden from 13:00 to 24:00 from vigilance level
SÉVÈRE (orange), and forbidden outright from vigilance level TRÈS SÉVÈRE
(red).[^arrete-26eb142] Users remain responsible and must keep continuous supervision, a means of
alert (mobile phone) and an adapted means of extinguishing fire immediately
available.[^arrete-26eb142]

## Controlled burning (brûlage dirigé)

Controlled burning for fire-prevention purposes can be carried out by the State, local
authorities and their groupings or agents (such as the Office National des Forêts and the SDIS)
and authorised syndical associations, with the landowners' written or tacit
agreement.[^arrete-26eb142] These bodies are responsible for the safety and sanitary conduct of
the operation and must ensure the person in charge of the work has been trained in controlled
burning or incineration by an establishment on a list jointly set by the ministers in charge of
forests and of the interior.[^arrete-26eb142]

## Ban on burning waste

Open-air burning, or burning with individual incinerators, of waste (household waste, green
waste, forestry green waste, agricultural green waste, industrial and craft waste, plastics,
rubber, treated wood, vegetable and mineral oils, hydrocarbons and derivatives) produced by
individuals, professionals and local authorities, is FORBIDDEN all year round across the whole
département of Charente-Maritime.[^arrete-26eb142] This waste must be taken to the nearest
déchetterie, recycled (composting, chipping, etc.) or directed to appropriate authorised
channels.[^arrete-26eb142]

### Dérogations

- A dérogation can be granted to professionals for burning contaminated green waste, in the
  context of fighting invasive exotic plant species, epiphytic diseases, parasitised wood,
  processionary caterpillars or termites, outside SÉVÈRE/TRÈS SÉVÈRE/EXCEPTIONNEL vigilance
  periods and outside the massifs, subject to the conditions on requests and fire safety set out
  in the order.[^arrete-26eb142] **Individuals cannot benefit from a dérogation** to burn green
  waste.[^arrete-26eb142]
- A dérogation can be granted to professionals or landowners for burning forestry green waste from
  land inaccessible to transport or chipping machinery, outside SÉVÈRE/TRÈS SÉVÈRE/EXCEPTIONNEL
  periods, subject to the same conditions.[^arrete-26eb142] Incineration of contaminated or
  pest-infected wood is allowed when ordered by the public authority (confirmed by the Service
  Régional de l'Alimentation / Département de la Santé des forêts, after advice of the Directeur
  Régional de l'Alimentation de l'Agriculture et de la Forêt), outside SÉVÈRE/TRÈS
  SÉVÈRE/EXCEPTIONNEL periods.[^arrete-26eb142]
- Burning of agricultural residue from pruning (hedges, fruit trees, vines, etc.) is allowed for
  agricultural professionals outside the massifs and outside SÉVÈRE/TRÈS SÉVÈRE/EXCEPTIONNEL
  periods, subject to the same conditions.[^arrete-26eb142] Burning of agricultural vegetation to
  fight pests harmful to plants is also allowed for agricultural professionals outside
  SÉVÈRE/TRÈS SÉVÈRE/EXCEPTIONNEL periods, under the Code rural et de la pêche maritime (articles
  D.615-47 and D.681-5), exceptionally, when necessary for duly justified agronomic or sanitary
  reasons ordered by the public authority after advice of the Directeur Régional de l'Alimentation
  de l'Agriculture et de la Forêt.[^arrete-26eb142]

## Conditions for festive fires and dérogation requests

Outside SÉVÈRE/TRÈS SÉVÈRE/EXCEPTIONNEL periods, a request can be exceptionally authorised under
the following conditions: the landowner or their beneficiary must apply to the mayor of the
commune concerned at least 5 clear working days before the planned date, specifying the
justification, the plot's location, the planned date or period, the duration, the volumes to be
burned, a description of the equipment used, the protection measures and the first means of
extinguishing fire planned, the applicant's contact details, and the landowner's
authorisation.[^arrete-26eb142] The mayor issues a written authorisation which is immediately
suspended during SÉVÈRE, TRÈS SÉVÈRE or EXCEPTIONNEL vigilance periods, and during air-pollution
episodes; this authorisation is sent to the gendarmerie, the national police for the relevant
areas, the Centre de Supervision et de Contrôle, and the ONF.[^arrete-26eb142]

Conditions to be met before lighting the fire include: checking that the day is not in a
SÉVÈRE/TRÈS SÉVÈRE/EXCEPTIONNEL vigilance period or an air-pollution episode; checking that
weather forecasts are compatible with incineration; keeping the fire under constant supervision
with extinguishing means in place before lighting and maintained throughout the operation until
complete extinction; for burning dérogations, not starting the hearth before 9h and extinguishing
it completely before 16h; having at least a means of alerting emergency services (mobile phone)
and an immediately available means of extinction; enclosing the hearth to avoid any risk of
spreading, with its surroundings cleared of combustible vegetation and ploughed or stripped over a
5-metre width, and not located under tree branches; keeping the hearth away from power and
telephone lines, more than 50 m from third parties' dwellings and from roads open to public
traffic; keeping the volume of vegetation piles to be incinerated compatible with a limited burning
duration, with piles not exceeding 5 m in diameter and 2 m in height; and not lighting fires using
inappropriate devices (old tyres, used oil, etc.).[^arrete-26eb142]

## Air pollution episodes

In the event of an atmospheric pollution episode involving particulate matter (PM10), ozone or
nitrogen dioxide, under prefectoral order n° 2017-731 of 6 April 2017, burning is forbidden
whenever the information, recommendation or alert thresholds triggered by the préfet are
exceeded; pollution episodes are published on the État services' website and on the ATMO
website.[^arrete-26eb142]

## Controls and sanctions

The mayor can use their police powers (article L.2212-2 of the Code général des collectivités
territoriales) to oppose an open-air fire if local circumstances (weather, safety, pollution)
require it, and must enforce the departmental sanitary regulation (règlement sanitaire
départemental, RSD), ensuring no green-waste burning takes place in the commune except under
dérogation; non-compliance with the RSD exposes the offender to the fine for **3rd-class
contraventions**.[^arrete-26eb142]

Under article R.610-5 of the Code pénal, violating the prohibitions or failing to meet the
obligations set by this order is punished by the fine for **1st-class
contraventions**.[^arrete-26eb142] Article R.163-2 of the Code forestier also provides the fine
for **4th-class contraventions** for any infringement of articles L.131-1 and L.131-6 et seq. of
the same code.[^arrete-26eb142]

For fires that burn woods, forests, moorlands, maquis, plantations or reforestations belonging to
others (started less than 200 m from such land, left without sufficient precautions, by
pyrotechnic articles lit or fired through negligence, or by equipment generating flammable
material or high heat), articles L.163-3 and L.163-4 of the Code forestier apply the sanctions of
the Code pénal.[^arrete-26eb142] Article 322-5 of the Code pénal punishes the involuntary
destruction, degradation or deterioration of property belonging to another with **two years'
imprisonment and a fine of 30,000 euros**.[^arrete-26eb142] A person who causes such a fire and
fails to act immediately to stop it, or to alert an administrative or police authority if their
action is insufficient, is subject to the second paragraph of article 322-5 of the Code
pénal.[^arrete-26eb142]

## Repeal and effective date

This order repeals prefectoral order n° 24EB441 of 1 July 2024 (the previous order regulating fire
use to prevent forest fires in Charente-Maritime), with effect from 1 May 2026, and itself enters
into force on 1 May 2026.[^arrete-26eb142]

## Previous order (arrêté n° 24EB441, 2024-2026, repealed)

*This section summarises the now-repealed order it replaced, kept for historical reference.*

According to the order itself, it was signed on 27 June 2024 and entered into application on 1
July 2024;[^arrete-24eb441] according to the repeal clause of its successor, order n° 26EB142
instead refers to it as the order "du 1er juillet 2024" (of 1 July 2024).[^arrete-26eb142] It was
repealed with effect from 1 May 2026.[^arrete-24eb441]

It already distinguished the same three fire-use contexts kept by its successor: "massifs à risque
feux" (risk massifs), "autres massifs" (other massifs) and "hors massifs boisés" (outside wooded
massifs).[^arrete-24eb441] It defined risk massifs as wooded massifs of more than 1 ha located in
the communes listed by the ministerial order of 6 February 2024, including the roads crossing them
and a 200-metre perimeter around them, and "autres massifs" as wooded massifs of at least 0.5 ha
anywhere in the département, with the same 200-metre perimeter rule.[^arrete-24eb441] It assessed
fire risk using three geographic sectors, Secteur 1 (1701), Secteur 2 (1702) and Secteur 3
(1703),[^arrete-24eb441] and the same six vigilance levels used by the current order: FAIBLE
(blue), LÉGER (green), MODÉRÉ (yellow), SÉVÈRE (orange), TRÈS SÉVÈRE (red) and EXCEPTIONNEL
(black).[^arrete-24eb441]

Under this order: throwing ignited objects (matches or other incandescent material) was forbidden
for everyone;[^arrete-24eb441] smoking was forbidden in both risk massifs and other massifs but
authorised outside wooded massifs;[^arrete-24eb441] and releasing flying lanterns ("lanternes
célestes/chinoises/thaïlandaises") was strictly forbidden across the whole département.[^arrete-24eb441]
Festive fires were forbidden in risk massifs, forbidden in other massifs from vigilance level
SÉVÈRE, and authorised for landowners and their beneficiaries outside massifs.[^arrete-24eb441]
Work with spark- or heat-generating equipment was forbidden from 13:00 to 24:00 from vigilance
level SÉVÈRE and forbidden outright from vigilance level TRÈS SÉVÈRE, but authorised outside
massifs.[^arrete-24eb441] Pyrotechnic shows and fireworks were forbidden from vigilance level
SÉVÈRE, except those fired at sea or from the foreshore with a 200-metre buffer zone from nearby
massifs, and strictly forbidden from vigilance level TRÈS SÉVÈRE.[^arrete-24eb441]

On cooking fires, the order's table authorised electric and gas barbecues, planchas and electric
stoves without restriction;[^arrete-24eb441] forbade gas stoves (réchauds à gaz) from vigilance
level SÉVÈRE in massifs while authorising them outside massifs;[^arrete-24eb441] forbade ground
cooking fires and mobile barbecues in massifs while authorising them outside massifs;[^arrete-24eb441]
and authorised charcoal, wood or petrol barbecues and stoves in massifs only on a prepared
non-combustible area under conditions, forbidding them from vigilance level
TRÈS SÉVÈRE.[^arrete-24eb441]

On waste burning, general green waste (households, professionals, local authorities) was forbidden
in both risk massifs and other massifs.[^arrete-24eb441] Outside massifs, professionals could burn
contaminated green waste only with a prefectoral dérogation, forbidden from vigilance level
SÉVÈRE;[^arrete-24eb441] forestry waste from inaccessible or contaminated land could be burned with
a dérogation under the same condition;[^arrete-24eb441] and agricultural residue from pruning
(hedges, fruit trees, vines) could be burned under conditions, also forbidden from vigilance level
SÉVÈRE.[^arrete-24eb441]

A request for festive fires or a burning dérogation had to be made to the mayor; fires had to be
lit under the continuous supervision of the landowner or occupant, who needed a means of alert,
outside any tree cover, with a 5-metre clearance of flammable material around the fire, compliance
with the legal brush-clearing obligations, and a water point or suitable extinguishing means
immediately available.[^arrete-24eb441] Festive fires had to be authorised by the landowner or
their beneficiaries, with other conditions set by articles 11 and 12 of the order.[^arrete-24eb441]
Complying with the order did not exempt a person who started a fire, voluntarily or through
negligence, from their liability towards third parties.[^arrete-24eb441] The risk-massif map was
published on Géoportail (geoportail.gouv.fr/donnees/debroussaillement), and the daily risk level on
Géo Plateforme 17 (geoplateforme17.fr/geosdis17) and the État services' website for
Charente-Maritime.[^arrete-24eb441]

## Departmental Forest Fire Protection Plan (PDPFCI)

Because it is exposed to fire risk, Charente-Maritime is among the départements for which the
Code forestier requires a Plan Départemental de Protection des Forêts contre les Incendies
(PDPFCI).[^cm-prevention-page] The Charente-Maritime PDPFCI 2018/2027 was approved by prefectoral
order on 20 November 2018.[^cm-prevention-page] Its regulations, established in the interest of
the safety of people, property and economic and social activities and for the protection of
natural environments, aim to reduce the number of forest-fire starts, reduce burnt areas, prevent
fire risk, and limit its consequences.[^cm-prevention-page] A prefectoral order on the legal
obligation to clear brush (OLD), dated 24 June 2025, complements this prevention
tool.[^cm-prevention-page]

For information, the prevention page lists the Direction Départementale des Territoires et de la
Mer (DDTM) de la Charente-Maritime, Service Eau, Biodiversité et Développement Durable, Unité
Milieux, Forêt et Biodiversité, as the contact point.[^cm-prevention-page]

## See also
- [Wildfire prevention and safety reflexes in France](wildfire-prevention-france.md)
- [Ban on burning green waste in France](green-waste-burning-ban-france.md)
- [Legal obligation to clear brush (débroussaillement) in France](legal-brush-clearing-obligation-france.md)

[^arrete-26eb142]: Arrêté préfectoral n° 26EB142 réglementant l'usage du feu à l'air libre
[^cm-prevention-page]: Prévention des incendies de forêt, d'espaces naturels et agricoles
[^arrete-24eb441]: Arrêté préfectoral n° 24EB441 du 27 juin 2024 réglementant l'usage du feu

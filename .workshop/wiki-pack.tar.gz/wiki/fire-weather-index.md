---
type: Topic
title: "Fire Weather Index (FWI) System"
description: "The Canadian FWI System used by EFFIS to compute fire danger, its classes, and related indices."
tags: [europe, fire-danger-index, methodology]
sources:
  - { id: effisfdf, resource: ../corpus/11-effis-fire-danger-forecast.html, title: "Fire Danger Forecast (technical background)" }
generated: { by: claude-sonnet-5, at: 2026-10-20T11:00:00Z }
---
# Fire Weather Index (FWI) System

In 2007, after a test phase of 5 years during which different national fire danger indices were
implemented in EFFIS, the EFFIS network adopted the Canadian Forest Fire Weather Index (FWI)
System as the method to assess the fire danger level in a harmonized way throughout
Europe.[^effisfdf]

## Forecast models

The fire danger forecast module of EFFIS provides access to fire danger indices using numerical
weather forecasts from two deterministic models: ECMWF (~8 km), which provides 1 to 9 day
forecasts, and MeteoFrance (~10 km), which provides up to 3 day forecasts.[^effisfdf] The model
can be selected in the pull-down menu of the EFFIS Current Situation Viewer.[^effisfdf]

## Ranking and anomaly

Given the different climatic conditions in Europe, EFFIS publishes two indicators derived from
the FWI that provide information on the local/temporal variability of the FWI compared to a
historical series of approximately 40 years.[^effisfdf] The **ranking** provides percentiles of
occurrence of the values; the **anomaly** is computed as a standard deviation from the 40-year
historical mean values.[^effisfdf]

## Fire danger classes

The FWI is mapped in 6 classes (low, medium, high, very high, extreme and very extreme).[^effisfdf]
The "Very Extreme" Fire Danger Class was introduced in June 2021 to provide discrimination about
the level of fire danger in extensive areas that were initially classified at "Extreme" Fire
Danger in the Mediterranean region during the summer months; it includes areas with FWI values
above 70.[^effisfdf] The fire danger classes are the same for all countries, and maps show a
harmonized picture of the spatial distribution of fire danger level throughout Europe, the
Middle East and North Africa.[^effisfdf]

The thresholds for the FWI and its sub-components, per class, are:[^effisfdf]

| Fire Danger Classes | FWI | FFMC | DMC | DC | ISI | BUI | Anomaly | Ranking |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Low | < 11.2 | < 82.7 | < 15.7 | < 256.1 | < 3.2 | < 24.2 | < 0.0 | < 80.0 |
| Moderate | 11.2 - 21.3 | 82.7 - 86.1 | 15.7 - 27.9 | 256.1 - 334.1 | 3.2 - 5.0 | 24.2 - 40.7 | 0.0 - 0.5 | 80.0 - 90.0 |
| High | 21.3 - 38.0 | 86.1 - 89.2 | 27.9 - 53.1 | 334.1 - 450.6 | 5.0 - 7.5 | 40.7 - 73.3 | 0.5 - 1.0 | 90.0 - 95.0 |
| Very High | 38.0 - 50.0 | 89.2 - 93.0 | 53.1 - 83.6 | 450.6 - 600.0 | 7.5 - 13.4 | 73.3 - 133.1 | 1.0 - 1.5 | 95.0 - 98.0 |
| Extreme | 50.0 - 70.0 | 93.0 - 96.0 | 83.6 - 160.7 | 600.0 - 749.4 | 13.4 - 26.8 | 133.1 - 193.1 | 1.5 - 2.5 | 98.0 - 99.0 |
| Very Extreme | > 70.0 | > 96.0 | > 160.7 | > 749.4 | > 26.8 | > 193.1 | > 2.5 | > 99.0 |

## Other indices and derived ratings

In 2019, due to the interest of countries in comparing the performance of the FWI with other
relevant fire danger indices, the Australian McArthur Forest Fire Danger Index (MARK-5), the
Keetch-Byram Drought Index (KBDI) and the National Fire Danger Rating System (NFDRS) were made
available through the EFFIS Fire Danger Forecast module; these are all computed from numerical
weather predictions of the ECMWF deterministic model.[^effisfdf]

A data-transformation model of the FWI is also used to provide a measure of fire control
difficulty: the Daily Severity Rating (DSR).[^effisfdf] Its average of daily estimates over a
week is called the Weekly Severity Rating (WSR), and it is provided in EFFIS through the Current
Statistics Portal.[^effisfdf]

## See also
- [European Forest Fire Information System (EFFIS)](effis.md)
- [Météo des forêts (France)](meteo-des-forets-france.md)
- [Pla Alfa (Catalonia)](pla-alfa-catalonia.md)

[^effisfdf]: Fire Danger Forecast (technical background)

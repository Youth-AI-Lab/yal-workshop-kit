---
type: Topic
title: "2025 EU wildfire season"
description: "Statistics on the 2025 wildfire season in the EU and in the wider EFFIS-monitored territories."
tags: [europe, statistics, wildfires]
sources:
  - { id: jrc2025, resource: ../corpus/10-jrc-eu-2025-wildfire-season.html, title: "2025 was EU's most destructive wildfire season on record" }
  - { id: advreport2025, resource: ../corpus/12-eu-advance-report-2025.html, title: "Advance Report on Forest Fires in Europe, Middle East and North Africa 2025" }
  - { id: echo2026, resource: ../corpus/90-echo-record-wildfires-2025.html, title: "Record number of wildfires in 2025 calls for stronger EU action" }
generated: { by: claude-sonnet-5, at: 2026-10-20T11:15:00Z }
---
# 2025 EU wildfire season

The 2025 fire season was the worst on record for the European Union.[^jrc2025] Satellite-based
analysis from the European Forest Fire Information System (EFFIS) shows that 1 079 538 hectares
– equivalent to approximately the area of Cyprus – were ravaged by fire across several EU
countries in 2025.[^jrc2025] This figure rises to 2 242 195 hectares when including the
territories in Europe, the Middle East and North Africa monitored by EFFIS.[^jrc2025]

The season started early, with over 100 000 hectares burnt within the EU by the end of March
2025.[^jrc2025] Intensity increased from June and peaked in August 2025, when very large fires
spread across several Mediterranean countries.[^jrc2025] A prolonged heatwave in the first three
weeks of August 2025 triggered 22 very large fires in Portugal and Spain almost simultaneously;
460 585 hectares were burnt, accounting for 43% of the total burnt area in the EU.[^jrc2025]
According to another source, the same August heatwave sparked 22 major fires in Portugal and
Spain burning 460,585 hectares – nearly half of the EU's total burnt area.[^echo2026]

In total, 7 783 fires mapped in 25 of the 27 EU Member States resulted in 1 079 538 burnt
hectares (only Luxembourg and Malta were left unburnt).[^jrc2025] This marks the highest burnt
area in the EU27 ever recorded by EFFIS since 2006, nearly double the 2006-2024 average.[^jrc2025]
Germany, Spain, Cyprus and Slovakia hit all-time records.[^jrc2025]

The share of burnt area within Europe's network of protected sites, Natura 2000, reached
approximately 39% in 2025, similar to previous years' figures; a total of 424 023 hectares were
burnt within these sites.[^jrc2025]

## Beyond the EU

In total, 2 242 195 hectares were burnt across all the territories analysed by EFFIS in
2025.[^jrc2025] Of this, 1 092 095 hectares were burnt in non-EU European countries and
70 562 hectares in the Middle East and North Africa.[^jrc2025]
According to one source, these 2 242 195 hectares cover all the territories analysed by EFFIS,
the EU included;[^jrc2025] according to another, "beyond the EU, wildfires ravaged 2.2 million
hectares across Europe, the Middle East, and North Africa".[^echo2026]
Beyond EU borders, Ukraine
emerged as the most impacted country in the area monitored by EFFIS, accounting for almost 30%
of the total mapped burnt area and 39% of all mapped fires.[^jrc2025]

The 2025 season reflects a clear trend: an earlier start, more frequent and intense heat waves,
and fires reaching higher latitudes than historically observed.[^jrc2025]

## Official advance report

An official advance report, "Advance Report on Forest Fires in Europe, Middle East and North
Africa 2025", was published on 12 October 2026, giving the annual summary of the 2025 wildfire
season based on EFFIS data.[^advreport2025] It is identified by the DOI
https://dx.doi.org/10.2760/3859043.[^advreport2025] The UCP Knowledge Network page announcing the
report gives its geographic focus as "all Europe/EU" and classifies it under the "Risk reduction &
assessment" sector, covering the prevention, response and recovery phases of disaster risk
management, and citing climate change and environmental degradation as risk
drivers.[^advreport2025] That page carries a disclaimer about the page itself: the information and
views "set out in this community page can also be those of the author" and do not necessarily
reflect the official opinion of the European Commission.[^advreport2025]

## See also
- [European Forest Fire Information System (EFFIS)](effis.md)
- [EU wildfire risk management](eu-wildfire-risk-management.md)

[^jrc2025]: 2025 was EU's most destructive wildfire season on record
[^advreport2025]: Advance Report on Forest Fires in Europe, Middle East and North Africa 2025
[^echo2026]: Record number of wildfires in 2025 calls for stronger EU action

---
type: Topic
title: "Pla Alfa (Catalonia)"
description: "Catalonia's Pla Alfa operational plan establishing 5 daily forest-fire danger levels at municipal scale, and the activity restrictions and civil-protection consequences triggered at each level."
tags: [catalonia, fire-danger-index, regulation]
sources:
  - { id: pla-alfa, resource: ../corpus/50-catalunya-pla-alfa.html, title: "Pla Alfa" }
generated: { by: claude-sonnet-5, at: 2026-10-20T00:00:00Z }
---
# Pla Alfa (Catalonia)

Pla Alfa is the operational procedure established by the Cos d'Agents Rurals (Catalonia's rural
agents corps) that defines the actions of its forest-fire surveillance and prevention personnel
deployed across the territory, in response to forest-fire danger situations.[^pla-alfa] The plan
is in force all year and daily assesses danger on a scale of 5 operational levels, from 0 (low
danger) to 4 (extreme danger).[^pla-alfa] All Pla Alfa levels are applied at municipal scale so
that preventive measures to protect people and the natural environment are more
precise.[^pla-alfa] The danger map is based on the daily forest-fire danger map produced by the
Servei d'Anàlisi de Perill d'Incendis Forestals (of the Departament d'Agricultura, Ramaderia,
Pesca i Alimentació) and other analysis tools, elaborated by the Direcció General dels Agents
Rurals; it is updated at 00:00 and at 9:30, or punctually if needed.[^pla-alfa] Activating each
level involves certain preventive actions and a degree of mobilisation of Agents Rurals
personnel.[^pla-alfa]

## Levels 0-2: low, moderate and high danger

At levels 0 (low danger), 1 (moderate danger) and 2 (high danger), Agents Rurals monitor
compliance with the restrictions on fire-risk activities set by the Departament d'Agricultura,
Ramaderia, Pesca i Alimentació.[^pla-alfa] To carry out an activity with fire risk, it is first
necessary to notify it to, or request authorisation from, that same department: a notification
regime applies from 16 October to 14 March, and an authorisation regime applies from 15 March to
15 October.[^pla-alfa] In both cases, Agents Rurals work to ensure compliance with the measures
set out in Decret 64/95 on forest-fire prevention measures, as well as the specific measures
detailed in the corresponding authorisation or notification.[^pla-alfa] Suspensions of fire-risk
activities are conditioned on the danger level determined by the daily forest-fire danger
map.[^pla-alfa]

## Level 3: very high danger

At level 3, all fire-risk activities previously authorised or notified are suspended.[^pla-alfa]
Agents Rurals carry out exclusive surveillance of these suspensions and of compliance with the
following prohibitions:[^pla-alfa]

- Lighting fire in any kind of open space.[^pla-alfa]
- Temporary suspension, while the risk remains, of all granted authorisations for burning
  stubble, permanent pastures, pruning residue and silvicultural residue.[^pla-alfa]
- Lighting fire in rest areas of the road network, as well as in recreational and camping zones,
  including zones equipped for that purpose.[^pla-alfa]
- Using machinery and equipment on forest land and in rural areas within a 500-metre strip around
  it, where its operation generates deflagration, sparks or electrical discharges, unless the
  competent authority of the regional administration has expressly authorised its use or it is
  necessary for fire extinction.[^pla-alfa]
- Introducing and using pyrotechnic material.[^pla-alfa]
- Throwing or abandoning burning objects or any material likely to start a fire.[^pla-alfa]
- Restrictions on using blowtorches, angle grinders and similar tools less than 500 metres from
  forest land.[^pla-alfa]

Activating Pla Alfa level 3, together with the analysis of other risk indicators, can lead to
declaring the pre-alert phase ("prealerta") of the Pla INFOCAT (Catalonia's civil-protection
plan).[^pla-alfa]

## Level 4: extreme danger

When episodes of extreme forest-fire danger occur and Pla Alfa level 4 is activated,
extraordinary measures are put in place in the affected municipalities.[^pla-alfa] Access to
protected natural spaces and other high-footfall forest areas may be restricted, except for
residents and essential services.[^pla-alfa] It may also involve restricting some activities in
the natural environment, set out in a resolution signed by the Conseller(a) of the Departament
d'Interior i Seguretat Pública.[^pla-alfa] The reason for these measures is to protect people in
extreme danger situations and reduce the fire risk that human activity can cause in forest
areas.[^pla-alfa] Activating level 4, together with the analysis of other risk indicators, means
activating the alert phase ("alerta") of the Pla INFOCAT.[^pla-alfa] At this level, Agents Rurals
are dedicated exclusively to monitoring compliance with these extraordinary measures and the
prohibition of fire-risk activities.[^pla-alfa]

## Contact

In case of an incident, people can call 935 617 000.[^pla-alfa] The general emergency phone
number 112 is also given as a contact.[^pla-alfa]

## See also
- [Fire Weather Index (FWI) System](fire-weather-index.md)
- [Météo des forêts (France)](meteo-des-forets-france.md)

[^pla-alfa]: Pla Alfa

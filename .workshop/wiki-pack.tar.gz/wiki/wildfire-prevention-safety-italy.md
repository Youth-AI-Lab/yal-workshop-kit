---
type: Topic
title: "Wildfire prevention and safety reflexes in Italy"
description: "Italian civil protection advice on preventing forest fires and on what to do while a fire is under way."
tags: [italy, prevention, what-to-do]
sources:
  - { id: pcm-incendio, resource: ../corpus/70-italia-in-caso-di-incendio.html, title: "In caso di incendio boschivo" }
generated: { by: claude_code/claude-opus-5-5, at: 2026-11-03T00:00:00Z }
---
# Wildfire prevention and safety reflexes in Italy

The Dipartimento della Protezione Civile (Italian civil protection department) publishes
recommendations to prevent forest fires and to react safely if one breaks out.[^pcm-incendio]

## Preventing a fire

- **Cigarettes and matches**: do not throw away lit cigarette butts or matches, as they can
  ignite dry grass.[^pcm-incendio]
- **Fires in the woods**: do not light fires in the woods; use only equipped areas, never leave
  a fire unattended, and make sure it is completely out before leaving.[^pcm-incendio]
- **Parking**: if parking a car, make sure the exhaust pipe is not in contact with dry grass, as
  a hot exhaust pipe can easily set grass alight.[^pcm-incendio]
- **Waste**: do not abandon waste in woods or at illegal dumps, as it is a dangerous
  fuel.[^pcm-incendio]
- **Stubble and agricultural residue**: do not burn stubble, straw or other agricultural residue
  without proper safety precautions, as control of the fire can be lost within minutes.[^pcm-incendio]

## What to do while a fire is under way

- **Alert**: anyone who spots flames or even just smoke should call the fire brigade's emergency
  number **115**, or, where activated, the single emergency number **112**, without assuming
  someone else has already done so, and should give the information needed to locate the
  fire.[^pcm-incendio]
- **Escape route**: look for a safe escape route, such as a road or a watercourse; do not stop in
  places the wind is blowing towards, as this risks being trapped between the flames with no way
  out.[^pcm-incendio]
- **Lie down**: lie down on the ground in a spot without flammable vegetation, since smoke tends
  to rise and lying down avoids breathing it in.[^pcm-incendio]
- **Crossing the fire as a last resort**: if there is no other choice, try to cross the fire where
  it is least intense, to reach the already-burnt area and get to a safe place.[^pcm-incendio]
- **Stay clear of roads**: a fire is not a spectacle; do not stand along roads, as this hinders
  rescue operations and the communications needed to manage the emergency.[^pcm-incendio]

## See also
- [2017 wildfires in the Vesuvius National Park](vesuvius-national-park-2017-wildfires.md)
- [Wildfire prevention and safety reflexes in France](wildfire-prevention-france.md)
- [Wildfire-prevention ordinance in Montoro (Ordinanza n. 78/2026)](wildfire-prevention-ordinance-montoro.md)
- [Bollettino di previsione nazionale incendi boschivi (Italy)](bollettino-previsione-incendi-italia.md)

[^pcm-incendio]: In caso di incendio boschivo
